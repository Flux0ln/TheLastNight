extends SceneTree
## Headless smoke test:  godot --headless --path . -s tests/smoke_test.gd
## Loads the level, waits for navmesh/AI setup, forces the Watcher into CHASE and checks it moves.
## NOTE: written but not executed in the authoring environment (no Godot binary available).

func _init() -> void:
	var scene: Node = load("res://scenes/levels/game.tscn").instantiate()
	root.add_child(scene)
	for i in 10:
		await physics_frame
	var ok := true
	var level := scene
	if level.player == null:
		push_error("FAIL: no player"); ok = false
	if level.watcher == null:
		push_error("FAIL: no watcher"); ok = false
	if ok:
		level.watcher.rage(level.player.global_position + Vector3(0, 0, -10))
		var start: Vector3 = level.watcher.global_position
		for i in 180:
			await physics_frame
		var moved: float = start.distance_to(level.watcher.global_position)
		print("watcher moved %.2f m in 3s (state %d)" % [moved, level.watcher.state])
		if moved < 1.0:
			push_error("FAIL: watcher did not move (navmesh/stuck?)"); ok = false
	print("SMOKE TEST: ", "PASS" if ok else "FAIL")
	quit(0 if ok else 1)
