#!/usr/bin/env python3
"""Static checks for scripts/managers/layout.gd (no Godot needed).
Verifies: data parses, items/doors sit on valid cells, rooms are sealed except through doors,
the key/fuse/power chain is solvable, and the exit is reachable. Run: python3 tests/validate_layout.py
"""
import json, re, sys, pathlib
from collections import deque

src = (pathlib.Path(__file__).parent.parent / "scripts/managers/layout.gd").read_text()
D = json.loads(src.split("const DATA := ", 1)[1])
W, H = D["w"], D["h"]
floor, doors, walls = {}, {}, set()
for r in D["rooms"]:
    x0, z0, x1, z1 = r["r"]
    for x in range(x0, x1 + 1):
        for z in range(z0, z1 + 1):
            floor[(x, z)] = r["id"]
for d in D["doors"]:
    doors[tuple(d["c"])] = d
for c in floor:
    for dx in (-1, 0, 1):
        for dz in (-1, 0, 1):
            n = (c[0] + dx, c[1] + dz)
            if n not in floor and n not in doors:
                walls.add(n)

errors = []
def check(cond, msg):
    if not cond:
        errors.append(msg)

for it in D["items"]:
    c = tuple(it["c"])
    if it["k"] == "note" and it["id"] == "n_car":
        check(c not in walls and c not in floor, "n_car should be outdoors")
    elif it["id"] in ("b_shed",):
        check(floor.get(c) == "shed", "shed battery not in shed")
    else:
        check(c in floor, f"item {it['id']} not on a floor cell {c}")
for p in D["patrol"]:
    check(tuple(p) in floor, f"patrol point {p} not on floor")
for s in D["scares"]:
    check(tuple(s["c"]) in floor and tuple(s["at"]) in floor, f"scare {s['id']} off floor")
check(tuple(D["exit_cell"]) in floor, "exit cell not on floor")
check(len({i["id"] for i in D["items"]}) == len(D["items"]), "duplicate item ids")
check(sum(1 for i in D["items"] if i["k"] == "fuse") == 3, "need exactly 3 fuses")
check(sum(1 for i in D["items"] if i["k"] == "note") == 8, "need exactly 8 notes")
check(set(D["notes"]) == {i["note"] for i in D["items"] if i["k"] == "note"}, "note ids mismatch")

for d in D["doors"]:
    c = tuple(d["c"])
    horiz = (c[0] - 1, c[1]) in walls and (c[0] + 1, c[1]) in walls
    a, b = ((c[0], c[1] - 1), (c[0], c[1] + 1)) if horiz else ((c[0] - 1, c[1]), (c[0] + 1, c[1]))
    sides = [x for x in (a, b) if x in floor or (x not in walls and x not in doors)]
    check(len(sides) == 2, f"door {d['id']} does not connect two open cells")

def passable(c, keys, power):
    if not (0 <= c[0] < W and 0 <= c[1] < H) or c in walls:
        return False
    if c in doors:
        d = doors[c]
        if d["lock"] and (d["lock"] not in keys or (d["power"] and not power)):
            return False
    return True

def reach(start, keys, power):
    seen, q = {start}, deque([start])
    while q:
        c = q.popleft()
        for dx, dz in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            n = (c[0] + dx, c[1] + dz)
            if n not in seen and passable(n, keys, power):
                seen.add(n); q.append(n)
    return seen

spawn = tuple(D["spawn"])
keys, power, fuses = set(), False, 0
for _ in range(10):
    r = reach(spawn, keys, power)
    for it in D["items"]:
        if tuple(it["c"]) in r and it["k"] == "key":
            keys.add(it["key"])
    fuses = sum(1 for it in D["items"] if it["k"] == "fuse" and tuple(it["c"]) in r)
    gen = next(i for i in D["items"] if i["k"] == "generator")
    if fuses >= 3 and tuple(gen["c"]) in r:
        power = True
r = reach(spawn, keys, power)
check(power, "power can never be restored")
check({"security_key", "bunker_key", "exit_card"} <= keys, f"keys unreachable: {keys}")
check(tuple(D["exit_cell"]) in r, "exit cell unreachable")
for it in D["items"]:
    if it["id"] != "term" or True:
        check(tuple(it["c"]) in r, f"item {it['id']} unreachable at end")

# before any key, sealed rooms must be unreachable
r0 = reach(spawn, set(), False)
for rid in ("security", "bunker", "escape"):
    check(not any(floor[c] == rid for c in r0 if c in floor), f"{rid} reachable without keys (leak)")
for rid in ("lobby", "office", "spine", "labw", "labe", "maint"):
    check(any(floor[c] == rid for c in r0 if c in floor), f"{rid} should be open from start")

if errors:
    print("FAIL"); [print(" -", e) for e in errors]; sys.exit(1)
print(f"OK: {len(D['rooms'])} rooms, {len(D['doors'])} doors, {len(D['items'])} items; key chain solvable; exit reachable.")
