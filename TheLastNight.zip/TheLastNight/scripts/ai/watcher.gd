extends CharacterBody3D
## THE WATCHER: low-poly monster with sight cone, hearing, search behaviour and stuck recovery.

enum S { DORMANT, STARE, PATROL, INVESTIGATE, SEARCH, CHASE }

var state: int = S.DORMANT
var state_t := 0.0
var player = null
var level = null
var patrol_points: Array = []
var nav: NavigationAgent3D
var target_pos := Vector3.ZERO
var last_known := Vector3.ZERO
var search_points: Array = []
var think_t := 0.0
var lost_t := 0.0
var stuck_t := 0.0
var stuck_check_t := 0.0
var last_pos := Vector3.ZERO
var unstick_count := 0
var calm_t := 0.0
var attack_cd := 0.0
var known_locker = null
var stare_time := 4.0
var after_stare: int = S.PATROL
var arm_l: Node3D
var arm_r: Node3D
var head_n: Node3D
var body_n: Node3D
var eye_mat: StandardMaterial3D
var breath: AudioStreamPlayer3D
var anim_t := 0.0
var step_dist := 0.0
var patrol_idx := -1


func _ready() -> void:
	add_to_group("watcher")
	collision_layer = 0
	collision_mask = 1
	var cs := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.4
	cap.height = 2.2
	cs.shape = cap
	cs.position.y = 1.1
	add_child(cs)
	nav = NavigationAgent3D.new()
	nav.path_desired_distance = 0.7
	nav.target_desired_distance = 1.0
	nav.radius = 0.5
	nav.avoidance_enabled = false
	add_child(nav)
	_build_model()
	breath = AudioStreamPlayer3D.new()
	breath.stream = Sfx.get_stream("breath")
	breath.bus = "SFX"
	breath.unit_size = 5.0
	breath.max_distance = 45.0
	breath.volume_db = -2.0
	add_child(breath)
	Game.noise_made.connect(_on_noise)
	visible = false
	set_physics_process(false)


func _mat(c: Color, emit := false) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = 1.0
	if emit:
		m.emission_enabled = true
		m.emission = c
		m.emission_energy_multiplier = 3.0
	return m


func _part(parent: Node3D, size: Vector3, pos: Vector3, mat: Material) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.position = pos
	mi.material_override = mat
	parent.add_child(mi)
	return mi


func _build_model() -> void:
	var dark := _mat(Color(0.035, 0.035, 0.045))
	eye_mat = _mat(Color(1.0, 0.25, 0.2), true)
	body_n = Node3D.new()
	add_child(body_n)
	_part(body_n, Vector3(0.16, 1.0, 0.16), Vector3(-0.15, 0.5, 0), dark)
	_part(body_n, Vector3(0.16, 1.0, 0.16), Vector3(0.15, 0.5, 0), dark)
	_part(body_n, Vector3(0.5, 1.0, 0.3), Vector3(0, 1.5, 0), dark)
	head_n = Node3D.new()
	head_n.position = Vector3(0, 2.25, 0.05)
	head_n.rotation.z = 0.2
	body_n.add_child(head_n)
	_part(head_n, Vector3(0.28, 0.4, 0.28), Vector3.ZERO, dark)
	_part(head_n, Vector3(0.06, 0.04, 0.02), Vector3(-0.07, 0.03, -0.15), eye_mat)
	_part(head_n, Vector3(0.06, 0.04, 0.02), Vector3(0.07, 0.03, -0.15), eye_mat)
	arm_l = Node3D.new()
	arm_l.position = Vector3(-0.36, 1.95, 0)
	body_n.add_child(arm_l)
	_part(arm_l, Vector3(0.1, 1.5, 0.1), Vector3(0, -0.75, 0), dark)
	arm_r = Node3D.new()
	arm_r.position = Vector3(0.36, 1.95, 0)
	body_n.add_child(arm_r)
	_part(arm_r, Vector3(0.1, 1.5, 0.1), Vector3(0, -0.75, 0), dark)


# ---------- spawning / scripted behaviour ----------
func _activate() -> void:
	visible = true
	collision_layer = 4
	set_physics_process(true)
	last_pos = global_position
	if not breath.playing:
		breath.play()


func wake_scripted(at: Vector3, secs: float, then: int) -> void:
	global_position = at
	_activate()
	stare_time = secs
	after_stare = then
	_set_state(S.STARE)


func wake_patrol() -> void:
	var far := _far_patrol_point()
	global_position = far
	_activate()
	_set_state(S.PATROL)


func rage(pos: Vector3) -> void:
	if state == S.DORMANT:
		global_position = _far_patrol_point()
		_activate()
	last_known = pos
	known_locker = null
	_set_state(S.CHASE)


func _far_patrol_point() -> Vector3:
	var best := Vector3.ZERO
	var best_d := -1.0
	for p in patrol_points:
		var d: float = p.distance_to(player.global_position)
		if d > best_d and d > 25.0:
			best = p
			best_d = d
	if best_d < 0.0 and not patrol_points.is_empty():
		best = patrol_points[0]
	return best


func player_hid(p, locker) -> void:
	if state == S.DORMANT or state == S.STARE:
		return
	if state == S.CHASE or _sees(true):
		known_locker = locker


# ---------- state machine ----------
func _set_state(s: int) -> void:
	var prev := state
	state = s
	state_t = 0.0
	match s:
		S.PATROL:
			target_pos = _next_patrol()
		S.INVESTIGATE:
			target_pos = last_known
		S.CHASE:
			lost_t = 0.0
			if prev != S.CHASE:
				Sfx.play_at("growl", global_position + Vector3(0, 1.5, 0), 4.0, 14.0, randf_range(0.85, 1.0))
				player.scare_kick()
		S.SEARCH:
			_build_search()


func _next_patrol() -> Vector3:
	if patrol_points.is_empty():
		return global_position
	for i in 6:
		var idx := randi() % patrol_points.size()
		if idx != patrol_idx and _dh(patrol_points[idx]) > 6.0:
			patrol_idx = idx
			return patrol_points[idx]
	patrol_idx = randi() % patrol_points.size()
	return patrol_points[patrol_idx]


func _snap(p: Vector3) -> Vector3:
	var s := NavigationServer3D.map_get_closest_point(nav.get_navigation_map(), p)
	if s == Vector3.ZERO and p.length() > 1.0:
		return p
	return s


func _build_search() -> void:
	search_points.clear()
	for i in 4:
		var off := Vector3(randf_range(-9.0, 9.0), 0.0, randf_range(-9.0, 9.0))
		search_points.append(_snap(last_known + off))
	target_pos = last_known


func _dh(p: Vector3) -> float:
	return Vector2(global_position.x - p.x, global_position.z - p.z).length()


func _reached(p: Vector3, r := 1.2) -> bool:
	return _dh(p) < r


func _speed() -> float:
	var d: float = Game.difficulty()
	match state:
		S.PATROL:
			return 1.7 * (0.9 + 0.1 * d)
		S.INVESTIGATE:
			return 2.8 * (0.9 + 0.1 * d)
		S.SEARCH:
			return 2.3
		S.CHASE:
			var s := 3.7 + 0.45 * (d - 1.0)
			if Game.run.get("power", false):
				s += 0.3
			return s
	return 0.0


func _sees(ignore_hidden := false) -> bool:
	if player == null or player.dead:
		return false
	if player.hidden and not ignore_hidden:
		return false
	var eye := global_position + Vector3(0, 2.1, 0)
	var tgt: Vector3 = player.global_position + Vector3(0, 0.6 if player.crouching else 1.2, 0)
	var to := tgt - eye
	var dist := to.length()
	var rng: float = 15.0 * sqrt(Game.difficulty()) * player.visibility_factor()
	if dist > rng:
		return false
	if dist > 3.5:
		var fwd := -global_transform.basis.z
		if fwd.angle_to(to) > deg_to_rad(55.0):
			return false
	var q := PhysicsRayQueryParameters3D.create(eye, tgt, 1 | 2 | 8, [get_rid()])
	var hit := get_world_3d().direct_space_state.intersect_ray(q)
	return not hit.is_empty() and hit["collider"] == player


func _on_noise(pos: Vector3, radius: float) -> void:
	if state == S.DORMANT or state == S.STARE or state == S.CHASE:
		return
	if Game.player_safe:
		return
	var scale_h: float = 0.9 + 0.1 * Game.difficulty()
	if _dh(pos) > radius * scale_h:
		return
	last_known = pos
	_set_state(S.INVESTIGATE)


func _physics_process(delta: float) -> void:
	state_t += delta
	attack_cd = maxf(0.0, attack_cd - delta)
	think_t -= delta
	if think_t <= 0.0:
		think_t = 0.4 if _dh(player.global_position) > 45.0 else 0.15
		_think()
	_move(delta)
	_stuck_check(delta)
	_footsteps(delta)


func _think() -> void:
	_open_doors()
	var sees := _sees()
	var dist := _dh(player.global_position)
	match state:
		S.STARE:
			if state_t >= stare_time or (after_stare != S.CHASE and dist < 5.0):
				if after_stare == S.CHASE or dist < 5.0:
					last_known = player.global_position
					_set_state(S.CHASE)
				else:
					_set_state(after_stare)
		S.PATROL:
			if sees:
				last_known = player.global_position
				_set_state(S.CHASE)
			elif _reached(target_pos) or state_t > 25.0:
				target_pos = _next_patrol()
				state_t = 0.0
		S.INVESTIGATE:
			if sees:
				last_known = player.global_position
				_set_state(S.CHASE)
			elif _reached(target_pos) or state_t > 12.0:
				_set_state(S.SEARCH)
		S.SEARCH:
			if sees:
				last_known = player.global_position
				_set_state(S.CHASE)
			elif player.hidden and dist < 2.2 and randf() < 0.12:
				known_locker = player.hiding_spot
				last_known = player.global_position
				_set_state(S.CHASE)
			elif _reached(target_pos) or state_t > 8.0:
				state_t = 0.0
				if search_points.is_empty():
					_set_state(S.PATROL)
				else:
					target_pos = search_points.pop_front()
		S.CHASE:
			_think_chase(sees, dist)


func _think_chase(sees: bool, dist: float) -> void:
	if player.dead:
		_set_state(S.PATROL)
		return
	if player.hidden:
		if known_locker != null and is_instance_valid(known_locker):
			target_pos = known_locker.global_position
			if _dh(target_pos) < 1.9 and attack_cd <= 0.0:
				known_locker = null
				player.exit_hide()
				_attack()
		else:
			lost_t += 0.15
			target_pos = last_known
			if lost_t > 1.0 or _reached(last_known):
				_set_state(S.SEARCH)
		return
	if sees:
		target_pos = player.global_position
		last_known = target_pos
		lost_t = 0.0
		if dist < 1.7 and attack_cd <= 0.0:
			_attack()
	else:
		lost_t += 0.15
		target_pos = last_known
		if lost_t > 3.5 or (_reached(last_known) and lost_t > 1.0):
			_set_state(S.SEARCH)


func _attack() -> void:
	attack_cd = 1.4
	Sfx.play_at("growl", global_position + Vector3(0, 1.5, 0), 6.0, 12.0, 1.1)
	player.take_damage(50.0)


func _open_doors() -> void:
	for d in get_tree().get_nodes_in_group("doors"):
		if not d.is_open and _dh(d.global_position) < 2.1:
			d.set_open(true, true)


func _face(dir: Vector3, delta: float, rate: float) -> void:
	var yaw := atan2(-dir.x, -dir.z)
	rotation.y = lerp_angle(rotation.y, yaw, clampf(rate * delta, 0.0, 1.0))


func _move(delta: float) -> void:
	if state == S.STARE:
		velocity = Vector3.ZERO
		_face(player.global_position - global_position, delta, 4.0)
		return
	if nav.target_position.distance_to(target_pos) > 0.4:
		nav.target_position = target_pos
	var next_pos := nav.get_next_path_position()
	var to_next := next_pos - global_position
	to_next.y = 0.0
	if to_next.length() < 0.15:
		to_next = target_pos - global_position
		to_next.y = 0.0
	var spd := _speed()
	if not _reached(target_pos, 0.8) and to_next.length() > 0.01:
		var dir := to_next.normalized()
		velocity.x = dir.x * spd
		velocity.z = dir.z * spd
		_face(dir, delta, 8.0)
	else:
		velocity.x = move_toward(velocity.x, 0.0, 20.0 * delta)
		velocity.z = move_toward(velocity.z, 0.0, 20.0 * delta)
	velocity.y = 0.0
	move_and_slide()
	global_position.y = 0.0


func _stuck_check(delta: float) -> void:
	stuck_check_t += delta
	if stuck_check_t < 0.5:
		return
	stuck_check_t = 0.0
	var moved := global_position.distance_to(last_pos)
	last_pos = global_position
	if state != S.STARE and not _reached(target_pos, 1.2) and moved < 0.12:
		stuck_t += 0.5
		if stuck_t >= 2.0:
			_unstick()
	else:
		stuck_t = 0.0
		calm_t += 0.5
		if calm_t > 8.0:
			unstick_count = 0


func _unstick() -> void:
	stuck_t = 0.0
	calm_t = 0.0
	unstick_count += 1
	if unstick_count == 1:
		global_position = _snap(global_position) + Vector3(randf_range(-0.8, 0.8), 0.0, randf_range(-0.8, 0.8))
		global_position.y = 0.0
		nav.target_position = target_pos
	else:
		unstick_count = 0
		global_position = _far_patrol_point()
		_set_state(S.PATROL)


func _footsteps(delta: float) -> void:
	var sp := Vector2(velocity.x, velocity.z).length()
	step_dist += sp * delta
	if step_dist > 2.0:
		step_dist = 0.0
		var surf: String = level.surface_at(global_position) if level != null else "concrete"
		Sfx.play_at("step_" + surf, global_position, 4.0, 10.0, 0.65)


func _process(delta: float) -> void:
	if state == S.DORMANT:
		return
	var sp := Vector2(velocity.x, velocity.z).length()
	anim_t += delta * (2.0 + sp * 2.2)
	var amp := minf(sp, 3.0) / 3.0
	arm_l.rotation.x = sin(anim_t) * 0.6 * amp + sin(anim_t * 0.4) * 0.05
	arm_r.rotation.x = -sin(anim_t) * 0.6 * amp - sin(anim_t * 0.45) * 0.05
	var lean := 0.3 if state == S.CHASE else 0.05
	body_n.rotation.x = lerpf(body_n.rotation.x, lean, minf(4.0 * delta, 1.0))
	head_n.rotation.z = 0.2 + sin(anim_t * 0.7) * 0.08
	var tw := sin(Time.get_ticks_msec() * 0.011)
	head_n.rotation.y = tw * 0.15 if fposmod(Time.get_ticks_msec() * 0.001, 5.0) < 0.6 else lerpf(head_n.rotation.y, 0.0, minf(5.0 * delta, 1.0))
	eye_mat.emission_energy_multiplier = 3.0 + (2.0 if state == S.CHASE else 0.0)
