extends CharacterBody3D
## First-person player: move/run/crouch, stamina, flashlight + battery, interaction, hiding, damage.

signal died

const WALK := 3.2
const RUN := 5.6
const CROUCH_SPEED := 1.6
const GRAVITY := 18.0
const STAND_H := 1.8
const CROUCH_H := 1.1

var level = null
var touch = null
var health := 100.0
var stamina := 100.0
var battery := 100.0
var flashlight_on := true
var crouching := false
var sprinting := false
var exhausted := false
var hidden := false
var hiding_spot = null
var dead := false
var frozen := false

var head: Node3D
var cam: Camera3D
var spot: SpotLight3D
var ray: RayCast3D
var shape: CapsuleShape3D
var col: CollisionShape3D
var pitch := 0.0
var bob_t := 0.0
var step_dist := 0.0
var shake := 0.0
var fov_kick := 0.0
var regen_delay := 0.0
var _prompt_t := 0.0
var _last_prompt := "\u0001"


func _ready() -> void:
	collision_layer = 2
	collision_mask = 1 | 8 | 32
	shape = CapsuleShape3D.new()
	shape.radius = 0.35
	shape.height = STAND_H
	col = CollisionShape3D.new()
	col.shape = shape
	col.position.y = STAND_H * 0.5
	add_child(col)
	head = Node3D.new()
	head.position.y = 1.6
	add_child(head)
	cam = Camera3D.new()
	cam.fov = 75.0
	cam.near = 0.05
	cam.far = 90.0
	head.add_child(cam)
	cam.make_current()
	spot = SpotLight3D.new()
	spot.spot_range = 24.0
	spot.spot_angle = 30.0
	spot.spot_attenuation = 0.6
	spot.light_energy = 2.8
	spot.shadow_enabled = Game.shadows_enabled()
	spot.position = Vector3(0.15, -0.1, 0.0)
	cam.add_child(spot)
	ray = RayCast3D.new()
	ray.target_position = Vector3(0, 0, -2.8)
	ray.collision_mask = 1 | 8 | 16
	ray.collide_with_areas = false
	ray.add_exception(self)
	cam.add_child(ray)


func connect_touch(t) -> void:
	touch = t
	t.interact_pressed.connect(do_interact)
	t.flashlight_pressed.connect(toggle_flashlight)
	t.reload_pressed.connect(use_battery)


func _unhandled_input(event: InputEvent) -> void:
	if dead or frozen:
		return
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		_look(event.relative * 0.0025 * float(Game.settings["sens"]))
	elif event.is_action_pressed("interact"):
		do_interact()
	elif event.is_action_pressed("flashlight"):
		toggle_flashlight()
	elif event.is_action_pressed("reload"):
		use_battery()


func _look(d: Vector2) -> void:
	rotate_y(-d.x)
	pitch = clampf(pitch - d.y, -1.4, 1.4)
	head.rotation.x = pitch


func _physics_process(delta: float) -> void:
	if dead or frozen:
		return
	_update_flashlight(delta)
	_update_camera_fx(delta)
	_update_prompt(delta)
	if Game.player_safe and health < 100.0:
		health = minf(100.0, health + 2.0 * delta)
	if hidden:
		return
	var input := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	var want_crouch := Input.is_action_pressed("crouch")
	var want_run := Input.is_action_pressed("sprint")
	if touch != null and touch.visible:
		input = (input + touch.move_vec).limit_length(1.0)
		want_crouch = want_crouch or touch.crouch_on
		want_run = want_run or touch.run_held
		var ld: Vector2 = touch.consume_look()
		if ld != Vector2.ZERO:
			_look(ld * 0.0042 * float(Game.settings["sens"]))
	crouching = want_crouch
	var moving := input.length() > 0.1
	sprinting = want_run and moving and not crouching and not exhausted and stamina > 0.0
	var speed := CROUCH_SPEED if crouching else (RUN if sprinting else WALK)
	if sprinting:
		stamina = maxf(0.0, stamina - 20.0 * delta)
		regen_delay = 1.2
		if stamina <= 0.0:
			exhausted = true
	else:
		regen_delay = maxf(0.0, regen_delay - delta)
		if regen_delay <= 0.0:
			stamina = minf(100.0, stamina + 16.0 * delta)
		if exhausted and stamina > 30.0:
			exhausted = false
	var dir := global_transform.basis * Vector3(input.x, 0.0, input.y)
	dir.y = 0.0
	var tgt := dir.normalized() * speed if moving else Vector3.ZERO
	velocity.x = move_toward(velocity.x, tgt.x, 30.0 * delta)
	velocity.z = move_toward(velocity.z, tgt.z, 30.0 * delta)
	if is_on_floor():
		velocity.y = -0.5
	else:
		velocity.y -= GRAVITY * delta
	move_and_slide()

	var h := lerpf(shape.height, CROUCH_H if crouching else STAND_H, minf(10.0 * delta, 1.0))
	shape.height = h
	col.position.y = h * 0.5
	var hspeed := Vector2(velocity.x, velocity.z).length()
	var bob := 0.0
	if hspeed > 0.5:
		bob_t += hspeed * delta * 2.6
		bob = sin(bob_t) * 0.035
	var base_y := 1.0 if crouching else 1.6
	head.position.y = lerpf(head.position.y, base_y + bob, minf(12.0 * delta, 1.0))
	step_dist += hspeed * delta
	var stride := 1.4 if crouching else (2.2 if sprinting else 2.6)
	if step_dist > stride:
		step_dist = 0.0
		_footstep()


func _footstep() -> void:
	var surf := "concrete"
	if level != null:
		surf = level.surface_at(global_position)
	var db := -16.0 if crouching else (0.0 if sprinting else -6.0)
	Sfx.play("step_" + surf, db, randf_range(0.9, 1.1))
	var radius := 3.0 if crouching else (16.0 if sprinting else 8.0)
	Game.make_noise(global_position, radius)


func _update_flashlight(delta: float) -> void:
	if flashlight_on and not hidden:
		battery = maxf(0.0, battery - 0.45 * delta)
		if battery <= 0.0:
			flashlight_on = false
	spot.visible = flashlight_on and not hidden
	if spot.visible:
		if battery < 15.0 and randf() < 0.12:
			spot.light_energy = 0.6
		else:
			spot.light_energy = 2.8


func toggle_flashlight() -> void:
	if dead or frozen or hidden:
		return
	if battery <= 0.0:
		Sfx.play("click", -4.0, 0.7)
		if level != null:
			level.hud.message("Battery dead. Press R / BATT to use a spare.")
		return
	flashlight_on = not flashlight_on
	Sfx.play("click")


func use_battery() -> void:
	if dead or frozen:
		return
	if int(Game.run["batteries"]) > 0 and battery < 95.0:
		Game.run["batteries"] = int(Game.run["batteries"]) - 1
		battery = 100.0
		Sfx.play("pickup", -6.0, 0.8)
		if level != null:
			level.hud.message("Battery replaced (%d spare left)" % int(Game.run["batteries"]))
	elif level != null:
		level.hud.message("No spare battery." if int(Game.run["batteries"]) == 0 else "Flashlight battery is fine.")


func _update_camera_fx(delta: float) -> void:
	shake = maxf(0.0, shake - 2.5 * delta)
	fov_kick = maxf(0.0, fov_kick - 20.0 * delta)
	cam.position = Vector3(randf_range(-1.0, 1.0), randf_range(-1.0, 1.0), 0.0) * shake * 0.02
	cam.fov = 75.0 + fov_kick


func scare_kick() -> void:
	shake = 1.0
	fov_kick = 8.0


func _update_prompt(delta: float) -> void:
	_prompt_t -= delta
	if _prompt_t > 0.0 or level == null:
		return
	_prompt_t = 0.08
	var text := ""
	if hidden:
		text = "Leave hiding spot"
	elif ray.is_colliding():
		var c = ray.get_collider()
		if c != null and c.has_method("prompt"):
			text = c.prompt(self)
	if text != _last_prompt:
		_last_prompt = text
		level.hud.set_prompt(text)


func do_interact() -> void:
	if dead or frozen:
		return
	if hidden:
		exit_hide()
		return
	if ray.is_colliding():
		var c = ray.get_collider()
		if c != null and c.has_method("interact"):
			c.interact(self)


func visibility_factor() -> float:
	var f := 1.0
	if crouching:
		f *= 0.6
	if flashlight_on and not hidden:
		f *= 1.35
	else:
		f *= 0.85
	if sprinting:
		f *= 1.15
	return f


func hide_in(locker) -> void:
	hidden = true
	hiding_spot = locker
	# Notify the monster BEFORE moving so it can tell whether it saw us enter.
	get_tree().call_group("watcher", "player_hid", self, locker)
	collision_layer = 0
	collision_mask = 0
	velocity = Vector3.ZERO
	global_position = locker.global_position
	var f: Vector3 = locker.face
	rotation.y = atan2(-f.x, -f.z)
	pitch = 0.0
	head.rotation.x = 0.0
	head.position.y = 1.5
	Sfx.play("door", -8.0, 1.4)
	if level != null:
		level.hud.set_hidden(true)
		level.hud.message("Hiding. Stay quiet.", 2.0)


func exit_hide() -> void:
	if not hidden:
		return
	var locker = hiding_spot
	hidden = false
	hiding_spot = null
	if locker != null and is_instance_valid(locker):
		global_position = locker.global_position + locker.face * 1.3
	collision_layer = 2
	collision_mask = 1 | 8 | 32
	if level != null:
		level.hud.set_hidden(false)


func take_damage(amount: float) -> void:
	if dead:
		return
	if hidden:
		exit_hide()
	health -= amount
	shake = 1.5
	fov_kick = 12.0
	Sfx.play("hurt")
	if level != null:
		level.hud.flash(Color(0.8, 0.0, 0.0, 0.55))
	if health <= 0.0:
		die()


func die() -> void:
	dead = true
	velocity = Vector3.ZERO
	died.emit()
