extends Control

const UITheme = preload("res://scripts/ui/ui_theme.gd")
const SettingsPanel = preload("res://scripts/ui/settings_panel.gd")

var menu_box: Control
var settings_box: Control
var credits_box: Control


func _ready() -> void:
	theme = UITheme.make()
	get_tree().paused = false
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	Sfx.start_menu_music()
	var bg := ColorRect.new()
	bg.color = Color(0.015, 0.015, 0.02)
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(bg)

	menu_box = CenterContainer.new()
	menu_box.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(menu_box)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 12)
	vb.custom_minimum_size = Vector2(420, 0)
	menu_box.add_child(vb)
	var t := Label.new()
	t.text = "THE LAST NIGHT"
	t.add_theme_font_size_override("font_size", 68)
	t.add_theme_color_override("font_color", Color(0.75, 0.08, 0.08))
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(t)
	var sub := Label.new()
	sub.text = "Halden Research Station - night shift"
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	sub.add_theme_color_override("font_color", Color(0.55, 0.55, 0.6))
	vb.add_child(sub)
	_btn(vb, "New Game", _new_game)
	var cont := _btn(vb, "Continue", _continue)
	cont.disabled = not Game.has_save()
	_btn(vb, "Settings", func():
		menu_box.visible = false
		settings_box.visible = true)
	_btn(vb, "Credits", func():
		menu_box.visible = false
		credits_box.visible = true)
	if not OS.has_feature("web"):
		_btn(vb, "Quit", func(): get_tree().quit())

	settings_box = CenterContainer.new()
	settings_box.set_anchors_preset(Control.PRESET_FULL_RECT)
	settings_box.visible = false
	add_child(settings_box)
	var sp := SettingsPanel.new()
	sp.closed.connect(func():
		settings_box.visible = false
		menu_box.visible = true)
	settings_box.add_child(sp)

	credits_box = CenterContainer.new()
	credits_box.set_anchors_preset(Control.PRESET_FULL_RECT)
	credits_box.visible = false
	add_child(credits_box)
	var pc := PanelContainer.new()
	credits_box.add_child(pc)
	var cv := VBoxContainer.new()
	cv.custom_minimum_size = Vector2(640, 0)
	pc.add_child(cv)
	var cl := Label.new()
	cl.text = "THE LAST NIGHT\n\nDesign, code, level layout, low-poly models (procedural primitives) and all audio (synthesized at runtime) are original. Released under the MIT License.\n\nBuilt with the Godot Engine (MIT License)."
	cl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	cv.add_child(cl)
	_btn(cv, "Back", func():
		credits_box.visible = false
		menu_box.visible = true)


func _btn(parent: Control, text: String, cb: Callable) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(0, 58)
	b.pressed.connect(cb)
	parent.add_child(b)
	return b


func _new_game() -> void:
	Game.start_mode = "new"
	Game.delete_save()
	_start()


func _continue() -> void:
	Game.start_mode = "continue"
	_start()


func _start() -> void:
	Sfx.stop_ambience()
	get_tree().change_scene_to_file("res://scenes/levels/game.tscn")
