extends Node
## Autoload "Game": settings, run state, checkpoint save/load, input map, audio buses.

signal noise_made(pos: Vector3, radius: float)

const SAVE_PATH := "user://savegame.json"
const SETTINGS_PATH := "user://settings.json"

var settings := {
	"master": 0.9, "music": 0.6, "sfx": 0.9, "sens": 1.0,
	"quality": 1, "touch": false, "touch_scale": 1.0,
}
var run: Dictionary = {}
var checkpoint: Dictionary = {}
var start_mode := "new"
var player_safe := false


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	settings["touch"] = OS.has_feature("mobile")
	_setup_input()
	load_settings()
	_setup_buses()
	apply_audio()
	run = new_run_state()
	_read_checkpoint_file()


func _setup_input() -> void:
	var map := {
		"move_forward": [KEY_W, KEY_UP], "move_back": [KEY_S, KEY_DOWN],
		"move_left": [KEY_A, KEY_LEFT], "move_right": [KEY_D, KEY_RIGHT],
		"sprint": [KEY_SHIFT], "crouch": [KEY_C, KEY_CTRL],
		"interact": [KEY_E], "flashlight": [KEY_F], "reload": [KEY_R],
		"pause": [KEY_ESCAPE],
	}
	for action in map:
		if not InputMap.has_action(action):
			InputMap.add_action(action)
		for k in map[action]:
			var ev := InputEventKey.new()
			ev.physical_keycode = k
			InputMap.action_add_event(action, ev)


func new_run_state() -> Dictionary:
	return {
		"pos": [], "health": 100.0, "battery": 100.0, "batteries": 1,
		"fuses_held": 0, "fuses_in": 0, "keys": [], "picked": [], "opened": [],
		"notes": [], "power": false, "purge": false, "scares": [], "entered": false,
	}


func difficulty() -> float:
	var d := 1.0 + 0.25 * float(run.get("fuses_in", 0))
	if run.get("power", false):
		d += 0.5
	return d


func make_noise(pos: Vector3, radius: float) -> void:
	noise_made.emit(pos, radius)


# ---------- settings ----------
func load_settings() -> void:
	if not FileAccess.file_exists(SETTINGS_PATH):
		return
	var parsed = JSON.parse_string(FileAccess.get_file_as_string(SETTINGS_PATH))
	if parsed is Dictionary:
		for k in parsed:
			if settings.has(k):
				settings[k] = parsed[k]


func save_settings() -> void:
	var f := FileAccess.open(SETTINGS_PATH, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(settings))


func _setup_buses() -> void:
	for n in ["Music", "SFX"]:
		if AudioServer.get_bus_index(n) == -1:
			AudioServer.add_bus()
			var i := AudioServer.bus_count - 1
			AudioServer.set_bus_name(i, n)
			AudioServer.set_bus_send(i, "Master")


func apply_audio() -> void:
	AudioServer.set_bus_volume_db(0, linear_to_db(maxf(float(settings["master"]), 0.0001)))
	var m := AudioServer.get_bus_index("Music")
	var s := AudioServer.get_bus_index("SFX")
	if m != -1:
		AudioServer.set_bus_volume_db(m, linear_to_db(maxf(float(settings["music"]), 0.0001)))
	if s != -1:
		AudioServer.set_bus_volume_db(s, linear_to_db(maxf(float(settings["sfx"]), 0.0001)))


func apply_quality(vp: Viewport) -> void:
	var q := int(settings["quality"])
	var scales := [0.6, 0.8, 1.0]
	vp.scaling_3d_mode = Viewport.SCALING_3D_MODE_BILINEAR
	vp.scaling_3d_scale = scales[q]
	vp.msaa_3d = Viewport.MSAA_2X if q == 2 else Viewport.MSAA_DISABLED
	Engine.max_fps = 60


func shadows_enabled() -> bool:
	return int(settings["quality"]) >= 1


# ---------- checkpoint / save ----------
func has_save() -> bool:
	return FileAccess.file_exists(SAVE_PATH)


func save_checkpoint() -> void:
	checkpoint = run.duplicate(true)
	var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(checkpoint))


func _read_checkpoint_file() -> void:
	if not has_save():
		return
	var parsed = JSON.parse_string(FileAccess.get_file_as_string(SAVE_PATH))
	if parsed is Dictionary:
		checkpoint = parsed


func delete_save() -> void:
	checkpoint = {}
	if has_save():
		DirAccess.remove_absolute(ProjectSettings.globalize_path(SAVE_PATH))
