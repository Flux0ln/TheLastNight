extends Node3D
## Builds the whole facility procedurally from layout.gd and runs the game rules.

const Layout = preload("res://scripts/managers/layout.gd")
const PlayerScr = preload("res://scripts/player/player.gd")
const WatcherScr = preload("res://scripts/ai/watcher.gd")
const InteractScr = preload("res://scripts/interaction/interactable.gd")
const DoorScr = preload("res://scripts/interaction/door.gd")
const HudScr = preload("res://scripts/ui/hud.gd")

const WALL_H := 3.2
const ROOM_COLORS := {
	"beige": Color(0.42, 0.38, 0.31), "dark": Color(0.14, 0.14, 0.17),
	"grey": Color(0.28, 0.29, 0.3), "teal": Color(0.17, 0.3, 0.3),
	"rust": Color(0.36, 0.2, 0.14),
}

var D: Dictionary = Layout.DATA
var C := 3.0
var floor_cells := {}
var door_cells := {}
var wall_cells := {}
var nav_region: NavigationRegion3D
var ceilings: Node3D
var player
var watcher
var hud
var lights: Array = []
var _mats := {}
var _event_t := 40.0
var _danger_smooth := 0.0
var _generator_pos := Vector3.ZERO
var _ending_shown := false
var _checkpoint_cd := 0.0


func _ready() -> void:
	randomize()
	C = float(D["cell"])
	if Game.start_mode == "continue" and not Game.checkpoint.is_empty():
		Game.run = Game.checkpoint.duplicate(true)
	else:
		Game.run = Game.new_run_state()
	Game.player_safe = false
	get_tree().paused = false
	Game.apply_quality(get_viewport())
	_setup_environment()
	_compute_cells()
	nav_region = NavigationRegion3D.new()
	add_child(nav_region)
	ceilings = Node3D.new()
	add_child(ceilings)
	_build_geometry()
	_build_outdoors()
	_bake_nav()
	_build_doors()
	_build_items()
	_build_lights()
	_build_areas()
	_build_player()
	_build_hud()
	Sfx.start_ambience()
	_update_objective()
	_update_power_visuals()
	await get_tree().physics_frame
	await get_tree().physics_frame
	_build_watcher()


# ---------- helpers ----------
func cw(c: float, r: float) -> Vector3:
	return Vector3((c + 0.5) * C, 0.0, (r + 0.5) * C)


func _mat(key: String, color: Color, emissive := false) -> StandardMaterial3D:
	if _mats.has(key):
		return _mats[key]
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = 1.0
	if emissive:
		m.emission_enabled = true
		m.emission = color
		m.emission_energy_multiplier = 1.4
	_mats[key] = m
	return m


func _solid_box(parent: Node, pos: Vector3, size: Vector3, mat: Material, layer := 1) -> StaticBody3D:
	var b := StaticBody3D.new()
	b.position = pos
	b.collision_layer = layer
	b.collision_mask = 0
	var cs := CollisionShape3D.new()
	var sh := BoxShape3D.new()
	sh.size = size
	cs.shape = sh
	b.add_child(cs)
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.material_override = mat
	b.add_child(mi)
	parent.add_child(b)
	return b


func _mesh_box(parent: Node, pos: Vector3, size: Vector3, mat: Material) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.position = pos
	mi.material_override = mat
	parent.add_child(mi)
	return mi


func _setup_environment() -> void:
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.01, 0.012, 0.018)
	env.fog_enabled = true
	env.fog_light_color = Color(0.03, 0.04, 0.05)
	env.fog_density = 0.045 if int(Game.settings["quality"]) == 0 else 0.035
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.12, 0.13, 0.17)
	env.ambient_light_energy = 0.4
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)


func _compute_cells() -> void:
	for room in D["rooms"]:
		var r: Array = room["r"]
		for x in range(int(r[0]), int(r[2]) + 1):
			for z in range(int(r[1]), int(r[3]) + 1):
				floor_cells[Vector2i(x, z)] = room["id"]
	for dr in D["doors"]:
		door_cells[Vector2i(int(dr["c"][0]), int(dr["c"][1]))] = dr
	for cell in floor_cells.keys():
		for dx in range(-1, 2):
			for dz in range(-1, 2):
				var n: Vector2i = cell + Vector2i(dx, dz)
				if not floor_cells.has(n) and not door_cells.has(n):
					wall_cells[n] = true


func surface_at(pos: Vector3) -> String:
	var cell := Vector2i(floori(pos.x / C), floori(pos.z / C))
	if floor_cells.has(cell):
		var rid: String = floor_cells[cell]
		return "metal" if (rid == "maint" or rid == "bunker") else "concrete"
	if door_cells.has(cell):
		return "concrete"
	return "grass"


# ---------- geometry ----------
func _build_geometry() -> void:
	var wall_mat := _mat("wall", Color(0.2, 0.21, 0.22))
	var ceil_mat := _mat("ceil", Color(0.1, 0.1, 0.11))
	for room in D["rooms"]:
		var r: Array = room["r"]
		var x0 := float(r[0])
		var z0 := float(r[1])
		var w := float(r[2] - r[0] + 1) * C
		var d := float(r[3] - r[1] + 1) * C
		var cx := (x0 + float(r[2]) + 1.0) * 0.5 * C
		var cz := (z0 + float(r[3]) + 1.0) * 0.5 * C
		var fm := _mat("floor_" + String(room["color"]), ROOM_COLORS[room["color"]])
		_solid_box(nav_region, Vector3(cx, -0.23, cz), Vector3(w, 0.5, d), fm)
		_mesh_box(ceilings, Vector3(cx, WALL_H + 0.25, cz), Vector3(w, 0.5, d), ceil_mat)
	for cell in door_cells.keys():
		var p := cw(cell.x, cell.y)
		_solid_box(nav_region, Vector3(p.x, -0.23, p.z), Vector3(C, 0.5, C), _mat("floor_grey", ROOM_COLORS["grey"]))
		_mesh_box(ceilings, Vector3(p.x, WALL_H + 0.25, p.z), Vector3(C, 0.5, C), ceil_mat)
	var gw := int(D["w"])
	var gh := int(D["h"])
	for row in range(gh):
		var start := -1
		for col in range(gw + 1):
			var is_w := wall_cells.has(Vector2i(col, row))
			if is_w and start < 0:
				start = col
			elif not is_w and start >= 0:
				var len_c := float(col - start)
				var pos := Vector3((float(start) + len_c * 0.5) * C, WALL_H * 0.5, (float(row) + 0.5) * C)
				_solid_box(nav_region, pos, Vector3(len_c * C, WALL_H, C), wall_mat)
				start = -1


func _build_outdoors() -> void:
	var cx := float(D["w"]) * C * 0.5
	var cz := float(D["h"]) * C * 0.5
	var ground := _solid_box(self, Vector3(cx, -0.5, cz), Vector3(220, 1.0, 220), _mat("ground", Color(0.05, 0.09, 0.05)))
	ground.collision_layer = 1
	# road from the entrance south
	var ex := (float(D["spawn"][0]) + 0.5) * C
	_mesh_box(self, Vector3(ex, 0.02, 20.0 * C + 35.0), Vector3(6.0, 0.04, 70.0), _mat("road", Color(0.08, 0.08, 0.09)))
	# invisible boundary
	var bnd := 68.0
	var inv := _mat("none", Color(0, 0, 0))
	for s in [Vector3(cx, 4, cz - bnd), Vector3(cx, 4, cz + bnd)]:
		var b := _solid_box(self, s, Vector3(2 * bnd, 8, 1), inv)
		b.get_child(1).visible = false
	for s in [Vector3(cx - bnd, 4, cz), Vector3(cx + bnd, 4, cz)]:
		var b := _solid_box(self, s, Vector3(1, 8, 2 * bnd), inv)
		b.get_child(1).visible = false
	_build_trees(cx, cz, bnd)
	_build_car()


func _build_trees(cx: float, cz: float, bnd: float) -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 424242
	var gw := float(D["w"]) * C
	var gh := float(D["h"]) * C
	var xforms: Array = []
	var tries := 0
	while xforms.size() < 220 and tries < 2000:
		tries += 1
		var x := rng.randf_range(cx - bnd + 2.0, cx + bnd - 2.0)
		var z := rng.randf_range(cz - bnd + 2.0, cz + bnd - 2.0)
		if x > -8.0 and x < gw + 8.0 and z > -8.0 and z < gh + 6.0:
			continue
		if absf(x - (float(D["spawn"][0]) + 0.5) * C) < 5.0 and z > gh - 6.0:
			continue
		xforms.append(Vector3(x, 0.0, z))
	var trunk_mesh := CylinderMesh.new()
	trunk_mesh.top_radius = 0.22
	trunk_mesh.bottom_radius = 0.3
	trunk_mesh.height = 2.0
	trunk_mesh.radial_segments = 5
	var leaf_mesh := CylinderMesh.new()
	leaf_mesh.top_radius = 0.0
	leaf_mesh.bottom_radius = 1.7
	leaf_mesh.height = 5.5
	leaf_mesh.radial_segments = 6
	var mm_t := MultiMesh.new()
	mm_t.transform_format = MultiMesh.TRANSFORM_3D
	mm_t.mesh = trunk_mesh
	mm_t.instance_count = xforms.size()
	var mm_l := MultiMesh.new()
	mm_l.transform_format = MultiMesh.TRANSFORM_3D
	mm_l.mesh = leaf_mesh
	mm_l.instance_count = xforms.size()
	var body := StaticBody3D.new()
	body.collision_layer = 1
	body.collision_mask = 0
	for i in xforms.size():
		var p: Vector3 = xforms[i]
		var sc := rng.randf_range(0.8, 1.5)
		var yaw := rng.randf_range(0.0, TAU)
		var bs := Basis(Vector3.UP, yaw).scaled(Vector3(sc, sc, sc))
		mm_t.set_instance_transform(i, Transform3D(bs, p + Vector3(0, 1.0 * sc, 0)))
		mm_l.set_instance_transform(i, Transform3D(bs, p + Vector3(0, (2.0 + 2.75) * sc, 0)))
		var cs := CollisionShape3D.new()
		var cyl := CylinderShape3D.new()
		cyl.radius = 0.5 * sc
		cyl.height = 3.0
		cs.shape = cyl
		cs.position = p + Vector3(0, 1.5, 0)
		body.add_child(cs)
	var mi_t := MultiMeshInstance3D.new()
	mi_t.multimesh = mm_t
	mi_t.material_override = _mat("trunk", Color(0.1, 0.06, 0.04))
	var mi_l := MultiMeshInstance3D.new()
	mi_l.multimesh = mm_l
	mi_l.material_override = _mat("leaf", Color(0.03, 0.12, 0.05))
	add_child(mi_t)
	add_child(mi_l)
	add_child(body)


func _build_car() -> void:
	var p := cw(8, 22)
	var car := Node3D.new()
	car.position = p
	car.rotation.y = 0.5
	add_child(car)
	var body_m := _mat("car", Color(0.25, 0.04, 0.04))
	var glass := _mat("glass", Color(0.05, 0.07, 0.09))
	var b := _solid_box(car, Vector3(0, 0.6, 0), Vector3(1.9, 0.8, 4.2), body_m)
	b.collision_layer = 1
	_mesh_box(car, Vector3(0, 1.3, -0.2), Vector3(1.7, 0.6, 2.2), glass)


func _bake_nav() -> void:
	var nm := NavigationMesh.new()
	nm.agent_radius = 0.5
	nm.agent_height = 2.0
	nm.agent_max_climb = 0.25
	nav_region.navigation_mesh = nm
	nav_region.bake_navigation_mesh(false)


# ---------- doors / items ----------
func _build_doors() -> void:
	var opened: Array = Game.run["opened"]
	for dr in D["doors"]:
		var cell := Vector2i(int(dr["c"][0]), int(dr["c"][1]))
		var horizontal := wall_cells.has(cell + Vector2i(-1, 0)) and wall_cells.has(cell + Vector2i(1, 0))
		var size := Vector3(C, WALL_H, 0.3) if horizontal else Vector3(0.3, WALL_H, C)
		var locked := String(dr["lock"]) != ""
		var mat := _mat("door_locked", Color(0.35, 0.08, 0.08)) if locked else _mat("door", Color(0.3, 0.22, 0.14))
		var door := DoorScr.new()
		door.level = self
		door.setup(String(dr["id"]), String(dr["lock"]), bool(dr["power"]), size, mat, WALL_H)
		var p := cw(cell.x, cell.y)
		door.position = Vector3(p.x, WALL_H * 0.5, p.z)
		add_child(door)
		if opened.has(dr["id"]):
			door.is_open = true
			door.shape.disabled = true
			door.position.y = door.open_y


func _wall_dir(cell: Vector2i) -> Vector3:
	for d in [Vector2i(0, -1), Vector2i(-1, 0), Vector2i(1, 0), Vector2i(0, 1)]:
		if wall_cells.has(cell + d):
			return Vector3(d.x, 0, d.y)
	return Vector3.ZERO


func _build_items() -> void:
	var picked: Array = Game.run["picked"]
	for it in D["items"]:
		var id: String = it["id"]
		var k: String = it["k"]
		var cell := Vector2i(int(it["c"][0]), int(it["c"][1]))
		var pos := cw(cell.x, cell.y)
		if k in ["battery", "fuse", "key"] and picked.has(id):
			continue
		var body := InteractScr.new()
		body.level = self
		body.kind = k
		body.id = id
		body.data = it
		add_child(body)
		match k:
			"locker":
				var wd := _wall_dir(cell)
				body.position = pos + wd * (C * 0.5 - 0.55)
				body.face = -wd if wd != Vector3.ZERO else Vector3(0, 0, 1)
				body.collision_layer = 1 | 16
				body.add_box_shape(Vector3(1.0, 2.0, 1.0), Vector3(0, 1.0, 0))
				_mesh_box(body, Vector3(0, 1.0, 0), Vector3(1.0, 2.0, 1.0), _mat("locker", Color(0.12, 0.17, 0.2)))
				_mesh_box(body, body.face * 0.51 + Vector3(0, 1.1, 0), Vector3(0.8, 1.7, 0.04), _mat("locker_door", Color(0.2, 0.26, 0.3)))
			"generator":
				body.position = pos
				_generator_pos = pos
				body.collision_layer = 1 | 16
				body.add_box_shape(Vector3(2.4, 1.8, 1.4), Vector3(0, 0.9, 0))
				_mesh_box(body, Vector3(0, 0.9, 0), Vector3(2.4, 1.8, 1.4), _mat("gen", Color(0.35, 0.3, 0.1)))
				_mesh_box(body, Vector3(0, 1.9, 0), Vector3(1.2, 0.2, 0.8), _mat("gen2", Color(0.15, 0.15, 0.15)))
			"terminal":
				body.position = pos
				body.collision_layer = 1 | 16
				body.add_box_shape(Vector3(1.0, 1.3, 0.6), Vector3(0, 0.65, 0))
				_mesh_box(body, Vector3(0, 0.65, 0), Vector3(1.0, 1.3, 0.6), _mat("term", Color(0.12, 0.12, 0.14)))
				_mesh_box(body, Vector3(0, 1.0, 0.31), Vector3(0.7, 0.4, 0.02), _mat("term_s", Color(0.1, 0.8, 0.3), true))
			_:
				body.position = pos
				body.collision_layer = 16
				body.add_box_shape(Vector3(0.6, 0.6, 0.6), Vector3(0, 0.95, 0))
				var crate := _solid_box(self, pos + Vector3(0, 0.35, 0), Vector3(0.8, 0.7, 0.8), _mat("crate", Color(0.2, 0.15, 0.1)), 32)
				crate.name = "Crate_" + id
				_pickup_mesh(body, k, it)


func _pickup_mesh(body: Node3D, k: String, it: Dictionary) -> void:
	var y := Vector3(0, 0.95, 0)
	match k:
		"battery":
			_mesh_box(body, y, Vector3(0.14, 0.3, 0.14), _mat("batt", Color(0.4, 0.9, 0.2), true))
		"fuse":
			_mesh_box(body, y, Vector3(0.1, 0.34, 0.1), _mat("fuse", Color(1.0, 0.5, 0.1), true))
		"key":
			var c := Color(0.9, 0.15, 0.15) if String(it["key"]) == "exit_card" else Color(0.9, 0.8, 0.2)
			_mesh_box(body, y, Vector3(0.3, 0.04, 0.2), _mat("key_" + String(it["key"]), c, true))
		"note":
			_mesh_box(body, y, Vector3(0.28, 0.02, 0.36), _mat("note", Color(0.9, 0.88, 0.8), true))


func _build_lights() -> void:
	for room in D["rooms"]:
		var n := int(room["lights"])
		if n <= 0:
			continue
		var r: Array = room["r"]
		var x0 := float(r[0]) * C
		var x1 := float(r[2] + 1) * C
		var z0 := float(r[1]) * C
		var z1 := float(r[3] + 1) * C
		var long_x := (x1 - x0) >= (z1 - z0)
		for i in n:
			var f := (float(i) + 0.5) / float(n)
			var pos := Vector3(lerpf(x0, x1, f) if long_x else (x0 + x1) * 0.5, 2.7, (z0 + z1) * 0.5 if long_x else lerpf(z0, z1, f))
			var l := OmniLight3D.new()
			l.position = pos
			l.omni_range = 8.0
			l.shadow_enabled = false
			add_child(l)
			_mesh_box(ceilings, Vector3(pos.x, WALL_H - 0.05, pos.z), Vector3(0.9, 0.08, 0.3), _mat("lamp", Color(1, 1, 1), true))
			lights.append({"n": l, "t": randf_range(1.0, 6.0), "burst": 0.0})


func _update_power_visuals() -> void:
	var on: bool = Game.run["power"]
	for l in lights:
		var n: OmniLight3D = l["n"]
		n.light_color = Color(1.0, 0.92, 0.8) if on else Color(1.0, 0.1, 0.06)
		l["base"] = 1.7 if on else 0.9


func _build_areas() -> void:
	for room in D["rooms"]:
		var r: Array = room["r"]
		var w := float(r[2] - r[0] + 1) * C
		var d := float(r[3] - r[1] + 1) * C
		var a := Area3D.new()
		a.collision_layer = 0
		a.collision_mask = 2
		a.position = Vector3((float(r[0] + r[2] + 1)) * 0.5 * C, 1.5, (float(r[1] + r[3] + 1)) * 0.5 * C)
		var cs := CollisionShape3D.new()
		var sh := BoxShape3D.new()
		sh.size = Vector3(w - 0.4, 3.0, d - 0.4)
		cs.shape = sh
		a.add_child(cs)
		add_child(a)
		var rid: String = room["id"]
		var safe: bool = room["safe"]
		a.body_entered.connect(func(_b): _on_room_enter(rid, safe))
		a.body_exited.connect(func(_b): _on_room_exit(safe))
	for sc in D["scares"]:
		var a2 := Area3D.new()
		a2.collision_layer = 0
		a2.collision_mask = 2
		a2.position = cw(float(sc["c"][0]), float(sc["c"][1])) + Vector3(0, 1.5, 0)
		var cs2 := CollisionShape3D.new()
		var sh2 := BoxShape3D.new()
		sh2.size = Vector3(C, 3.0, C)
		cs2.shape = sh2
		a2.add_child(cs2)
		add_child(a2)
		var sd: Dictionary = sc
		a2.body_entered.connect(func(_b): _on_scare(sd))
	var xa := Area3D.new()
	xa.collision_layer = 0
	xa.collision_mask = 2
	xa.position = cw(float(D["exit_cell"][0]), float(D["exit_cell"][1])) + Vector3(0, 1.5, 0)
	var xcs := CollisionShape3D.new()
	var xsh := BoxShape3D.new()
	xsh.size = Vector3(C, 3.0, C)
	xcs.shape = xsh
	xa.add_child(xcs)
	add_child(xa)
	xa.body_entered.connect(func(_b): _on_exit_reached())


func _on_room_enter(rid: String, safe: bool) -> void:
	if not Game.run["entered"] and rid == "lobby":
		Game.run["entered"] = true
		_update_objective()
	if safe:
		Game.player_safe = true
		if _checkpoint_cd <= 0.0:
			capture_checkpoint()


func _on_room_exit(safe: bool) -> void:
	if safe:
		Game.player_safe = false


func _on_scare(sc: Dictionary) -> void:
	var scares: Array = Game.run["scares"]
	if scares.has(sc["id"]) or watcher == null or player.dead:
		return
	if watcher.state == WatcherScr.S.CHASE:
		return
	scares.append(sc["id"])
	Sfx.silence(2.5)
	Sfx.play("stinger", -6.0)
	for l in lights:
		l["burst"] = 0.6
	var at := cw(float(sc["at"][0]), float(sc["at"][1]))
	var then := WatcherScr.S.CHASE if String(sc["then"]) == "chase" else WatcherScr.S.PATROL
	watcher.wake_scripted(at, float(sc["stare"]), then)


# ---------- player / hud / watcher ----------
func _build_player() -> void:
	player = PlayerScr.new()
	player.level = self
	add_child(player)
	var pos: Array = Game.run["pos"]
	if pos.size() == 3:
		player.global_position = Vector3(float(pos[0]), float(pos[1]), float(pos[2]))
	else:
		var s: Array = D["spawn"]
		player.global_position = cw(float(s[0]), float(s[1]))
		player.rotation.y = 0.0
	player.health = float(Game.run["health"])
	player.battery = float(Game.run["battery"])
	player.died.connect(_on_player_died)
	if not bool(Game.settings["touch"]):
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED


func _build_hud() -> void:
	hud = HudScr.new()
	add_child(hud)
	player.connect_touch(hud.touch)
	hud.restart_requested.connect(_restart)
	hud.menu_requested.connect(_to_menu)


func _build_watcher() -> void:
	watcher = WatcherScr.new()
	watcher.player = player
	watcher.level = self
	var pts: Array = []
	for p in D["patrol"]:
		pts.append(cw(float(p[0]), float(p[1])))
	watcher.patrol_points = pts
	add_child(watcher)
	if Game.run["scares"].has("s1"):
		watcher.wake_patrol()
	if Game.run["power"]:
		watcher.rage(player.global_position)


func _on_player_died() -> void:
	Sfx.set_danger(0.0)
	hud.show_death()


func _restart() -> void:
	Game.start_mode = "continue" if not Game.checkpoint.is_empty() else "new"
	get_tree().paused = false
	get_tree().reload_current_scene()


func _to_menu() -> void:
	get_tree().paused = false
	Sfx.stop_ambience()
	get_tree().change_scene_to_file("res://scenes/menus/main_menu.tscn")


func capture_checkpoint() -> void:
	var r: Dictionary = Game.run
	r["pos"] = [player.global_position.x, player.global_position.y, player.global_position.z]
	r["health"] = player.health
	r["battery"] = player.battery
	Game.save_checkpoint()
	_checkpoint_cd = 20.0
	hud.message("Checkpoint saved", 2.0)


# ---------- interaction rules ----------
func _has_key(k: String) -> bool:
	return Game.run["keys"].has(k)


func prompt_for(it) -> String:
	match it.kind:
		"battery": return "Take spare battery"
		"fuse": return "Take fuse"
		"key": return "Take " + String(it.data["name"])
		"note": return "Read note"
		"locker": return "Hide"
		"terminal": return "Use terminal"
		"generator":
			if int(Game.run["fuses_held"]) > 0:
				return "Insert fuse (%d/3)" % int(Game.run["fuses_in"])
			return "Generator (%d/3 fuses installed)" % int(Game.run["fuses_in"])
	return ""


func prompt_for_door(door) -> String:
	if door.is_open:
		return "Close door"
	if door.lock != "" and not Game.run["opened"].has(door.id):
		if door.needs_power and not Game.run["power"]:
			return "Locked - no power"
		if not _has_key(door.lock):
			return "Locked - needs " + String(door.lock).replace("_", " ")
		return "Unlock"
	return "Open door"


func handle_door(door, p) -> void:
	if door.is_open:
		if Vector2(p.global_position.x - door.global_position.x, p.global_position.z - door.global_position.z).length() < 1.7:
			hud.message("Step back to close the door.")
			return
		door.set_open(false)
		return
	if door.lock != "" and not Game.run["opened"].has(door.id):
		if (door.needs_power and not Game.run["power"]) or not _has_key(door.lock):
			Sfx.play_at("locked", door.global_position, 0.0, 8.0)
			Game.make_noise(door.global_position, 5.0)
			hud.message(prompt_for_door(door))
			return
		Game.run["opened"].append(door.id)
		hud.message("Unlocked")
	door.set_open(true)


func handle_interact(it, p) -> void:
	match it.kind:
		"battery":
			Game.run["batteries"] = int(Game.run["batteries"]) + 1
			_take(it)
			hud.message("Spare battery (%d)" % int(Game.run["batteries"]))
		"fuse":
			Game.run["fuses_held"] = int(Game.run["fuses_held"]) + 1
			_take(it)
			hud.message("Fuse collected. Take it to the generator.")
			_update_objective()
		"key":
			Game.run["keys"].append(it.data["key"])
			_take(it)
			hud.message(String(it.data["name"]) + " acquired")
			_update_objective()
		"note":
			var nid: String = it.data["note"]
			if not Game.run["notes"].has(nid):
				Game.run["notes"].append(nid)
			Sfx.play("pickup", -8.0, 0.6)
			var n: Dictionary = D["notes"][nid]
			hud.show_note(String(n["title"]) + " (%d/8)" % Game.run["notes"].size(), String(n["text"]))
		"locker":
			p.hide_in(it)
		"generator":
			_insert_fuse(p)
		"terminal":
			if not Game.run["power"]:
				hud.message("Terminal offline - no power.")
			elif Game.run["purge"]:
				hud.message("PURGE already armed. Leave through the gate.")
			else:
				Game.run["purge"] = true
				Sfx.play("stinger", -4.0)
				hud.message("PURGE SEQUENCE ARMED. Burn it all. Now leave.", 4.0)


func _take(it) -> void:
	Game.run["picked"].append(it.id)
	Sfx.play("pickup")
	Game.make_noise(it.global_position, 3.0)
	var crate := get_node_or_null("Crate_" + String(it.id))
	if crate != null:
		crate.queue_free()
	it.queue_free()


func _insert_fuse(p) -> void:
	if int(Game.run["fuses_held"]) <= 0:
		hud.message("The generator needs 3 fuses (%d/3 installed)." % int(Game.run["fuses_in"]))
		Sfx.play("locked", -4.0)
		return
	Game.run["fuses_held"] = int(Game.run["fuses_held"]) - 1
	Game.run["fuses_in"] = int(Game.run["fuses_in"]) + 1
	Sfx.play_at("clang", _generator_pos + Vector3(0, 1, 0), 2.0, 14.0)
	Game.make_noise(_generator_pos, 24.0)
	hud.message("Fuse installed (%d/3). That was LOUD." % int(Game.run["fuses_in"]))
	if int(Game.run["fuses_in"]) >= 3:
		_power_on()
	else:
		capture_checkpoint()
	_update_objective()


func _power_on() -> void:
	Game.run["power"] = true
	_update_power_visuals()
	Sfx.start_alarm(8.0)
	Sfx.play("stinger", -2.0)
	hud.message("POWER RESTORED. The Watcher heard it. RUN.", 4.0)
	capture_checkpoint()
	if watcher != null:
		watcher.rage(player.global_position)


func _update_objective() -> void:
	var r: Dictionary = Game.run
	var found := int(r["fuses_held"]) + int(r["fuses_in"])
	var t := ""
	if not r["entered"]:
		t = "Get inside Halden Station. The lobby door is north of the road."
	elif not r["power"]:
		if found < 3:
			t = "Find the generator fuses (%d/3). Search the labs and security." % found
		else:
			t = "Install the fuses at the generator in the north maintenance hall."
	elif not _has_key("exit_card"):
		t = "Power is on. Find the exit card in the bunker, then reach the north gate."
	else:
		t = "Reach the north gate. RUN."
	hud.set_objective(t)


func _on_exit_reached() -> void:
	if _ending_shown or player.dead:
		return
	if not Game.run["power"]:
		return
	_ending_shown = true
	var key := "ESCAPE"
	if Game.run["purge"]:
		key = "PURGE"
	elif Game.run["notes"].size() >= 8:
		key = "TRUTH"
	var e: Dictionary = D["endings"][key]
	player.frozen = true
	Sfx.set_danger(0.0)
	hud.show_ending(String(e["title"]), String(e["text"]))


# ---------- per-frame ----------
func _process(delta: float) -> void:
	if player == null:
		return
	_checkpoint_cd = maxf(0.0, _checkpoint_cd - delta)
	hud.set_stats(player.health, player.stamina, player.battery,
		"Batteries %d   Fuses %d/3   Notes %d/8\nKeys: %s" % [
			int(Game.run["batteries"]), int(Game.run["fuses_held"]) + int(Game.run["fuses_in"]),
			Game.run["notes"].size(), _keys_text()])
	_flicker(delta)
	_danger(delta)
	_random_events(delta)


func _keys_text() -> String:
	if Game.run["keys"].is_empty():
		return "-"
	var parts: Array = []
	for k in Game.run["keys"]:
		parts.append(String(k).replace("_", " "))
	return ", ".join(parts)


func _flicker(delta: float) -> void:
	var tick := int(Time.get_ticks_msec() / 45)
	for l in lights:
		var n: OmniLight3D = l["n"]
		var base: float = l.get("base", 1.0)
		l["t"] -= delta
		if l["t"] < 0.0:
			l["t"] = randf_range(2.0, 9.0)
			if randf() < 0.4:
				l["burst"] = 0.25
		if l["burst"] > 0.0:
			l["burst"] -= delta
			n.light_energy = base * (0.1 if tick % 2 == 0 else 1.0)
		else:
			n.light_energy = base


func _danger(delta: float) -> void:
	var target := 0.0
	if watcher != null and watcher.state != WatcherScr.S.DORMANT and not player.dead:
		var d := Vector2(player.global_position.x - watcher.global_position.x, player.global_position.z - watcher.global_position.z).length()
		target = clampf(1.0 - d / 28.0, 0.0, 1.0)
		if watcher.state == WatcherScr.S.CHASE:
			target = maxf(target, 0.85)
	_danger_smooth = lerpf(_danger_smooth, target, minf(2.0 * delta, 1.0))
	Sfx.set_danger(_danger_smooth)
	hud.set_danger(_danger_smooth)


func _random_events(delta: float) -> void:
	_event_t -= delta
	if _event_t > 0.0:
		return
	_event_t = randf_range(30.0, 60.0)
	match randi() % 3:
		0:
			var ang := randf() * TAU
			var pos: Vector3 = player.global_position + Vector3(cos(ang), 1.0, sin(ang)) * randf_range(18.0, 30.0)
			Sfx.play_at("clang", pos, -2.0, 10.0, randf_range(0.7, 1.1))
		1:
			for l in lights:
				l["burst"] = randf_range(0.2, 0.8)
		2:
			Sfx.silence(3.0)
