extends RefCounted
# Pure level data. JSON-compatible on purpose so tests/validate_layout.py can parse it.
const DATA := {
"cell": 3.0, "w": 26, "h": 25,
"spawn": [12, 22],
"exit_cell": [23, 3],
"rooms": [
{"id": "lobby", "r": [8, 15, 17, 18], "color": "beige", "safe": false, "lights": 2},
{"id": "office", "r": [2, 15, 6, 18], "color": "beige", "safe": true, "lights": 1},
{"id": "security", "r": [19, 15, 23, 18], "color": "dark", "safe": false, "lights": 1},
{"id": "spine", "r": [12, 6, 13, 13], "color": "grey", "safe": false, "lights": 3},
{"id": "labw", "r": [3, 7, 10, 11], "color": "teal", "safe": false, "lights": 2},
{"id": "labe", "r": [15, 7, 22, 11], "color": "teal", "safe": false, "lights": 2},
{"id": "bunker", "r": [3, 13, 9, 13], "color": "dark", "safe": true, "lights": 1},
{"id": "maint", "r": [2, 2, 18, 4], "color": "rust", "safe": false, "lights": 4},
{"id": "escape", "r": [20, 2, 24, 4], "color": "grey", "safe": false, "lights": 1},
{"id": "shed", "r": [18, 22, 20, 23], "color": "rust", "safe": false, "lights": 0}
],
"doors": [
{"id": "d_entrance", "c": [12, 19], "lock": "", "power": false},
{"id": "d_office", "c": [7, 16], "lock": "", "power": false},
{"id": "d_security", "c": [18, 16], "lock": "security_key", "power": false},
{"id": "d_spine", "c": [12, 14], "lock": "", "power": false},
{"id": "d_labw", "c": [11, 9], "lock": "", "power": false},
{"id": "d_labe", "c": [14, 9], "lock": "", "power": false},
{"id": "d_bunker", "c": [5, 12], "lock": "bunker_key", "power": false},
{"id": "d_maint", "c": [12, 5], "lock": "", "power": false},
{"id": "d_exit", "c": [19, 3], "lock": "exit_card", "power": true},
{"id": "d_shed", "c": [19, 21], "lock": "", "power": false}
],
"items": [
{"id": "n_car", "k": "note", "c": [9, 22], "note": "n_car"},
{"id": "b_shed", "k": "battery", "c": [18, 23]},
{"id": "n_lobby", "k": "note", "c": [9, 15], "note": "n_lobby"},
{"id": "b_lobby", "k": "battery", "c": [16, 18]},
{"id": "key_sec", "k": "key", "c": [3, 18], "key": "security_key", "name": "Security Key"},
{"id": "n_office", "k": "note", "c": [6, 15], "note": "n_office"},
{"id": "l_office", "k": "locker", "c": [2, 16]},
{"id": "f_labw", "k": "fuse", "c": [4, 8]},
{"id": "n_labw", "k": "note", "c": [10, 7], "note": "n_labw"},
{"id": "b_labw", "k": "battery", "c": [3, 11]},
{"id": "l_labw", "k": "locker", "c": [3, 7]},
{"id": "f_labe", "k": "fuse", "c": [21, 10]},
{"id": "n_labe", "k": "note", "c": [22, 7], "note": "n_labe"},
{"id": "b_labe", "k": "battery", "c": [18, 7]},
{"id": "l_labe", "k": "locker", "c": [15, 11]},
{"id": "f_sec", "k": "fuse", "c": [22, 18]},
{"id": "key_bun", "k": "key", "c": [23, 15], "key": "bunker_key", "name": "Bunker Key"},
{"id": "n_sec", "k": "note", "c": [20, 18], "note": "n_sec"},
{"id": "l_sec", "k": "locker", "c": [23, 17]},
{"id": "gen", "k": "generator", "c": [9, 3]},
{"id": "n_maint", "k": "note", "c": [5, 2], "note": "n_maint"},
{"id": "b_m1", "k": "battery", "c": [6, 4]},
{"id": "b_m2", "k": "battery", "c": [15, 4]},
{"id": "l_m1", "k": "locker", "c": [2, 4]},
{"id": "l_m2", "k": "locker", "c": [16, 2]},
{"id": "card", "k": "key", "c": [9, 13], "key": "exit_card", "name": "Exit Card"},
{"id": "b_bun1", "k": "battery", "c": [7, 13]},
{"id": "b_bun2", "k": "battery", "c": [4, 13]},
{"id": "n_bun", "k": "note", "c": [3, 13], "note": "n_bun"},
{"id": "term", "k": "terminal", "c": [24, 2]}
],
"patrol": [[12, 16], [10, 16], [12, 10], [6, 9], [18, 9], [6, 3], [14, 3], [10, 3], [21, 17]],
"scares": [
{"id": "s1", "c": [12, 12], "at": [13, 6], "stare": 4.5, "then": "patrol"},
{"id": "s2", "c": [16, 9], "at": [22, 8], "stare": 3.0, "then": "chase"},
{"id": "s3", "c": [12, 4], "at": [3, 3], "stare": 3.5, "then": "patrol"}
],
"notes": {
"n_car": {"title": "Dispatch Memo", "text": "Halden Station, night shift. Gate code changed. Radio dead since 11 PM. Do not leave the car running. If the lights inside go red, stay on the road and call it in. - Dispatch"},
"n_lobby": {"title": "Reception Log", "text": "Staff evacuated at 2 AM. Security was told to lock down and keep the night guard inside. Nobody told me why. The north gate needs a card AND main power. The card is in the bunker."},
"n_office": {"title": "Email - Dr. Vance", "text": "The Watcher reacts to sound first, light second. It does not smell. It listens. Walk softly, crouch near it, and never run unless you must. It cannot be reasoned with."},
"n_labw": {"title": "Lab Report 7-A", "text": "Subject 7 tracks footsteps, dropped objects, and noisy machines. If you break line of sight and stay quiet, it will search the last place it heard you. Lockers do not save you if it watched you climb in."},
"n_labe": {"title": "Incident Note", "text": "We cut the power for an audit and the cage doors failed. Restoring power will wake the whole building. Whoever does it needs a clear run to the north gate."},
"n_sec": {"title": "Guard Log - M. Reyes", "text": "Marcus hid in a locker. It knew. They always know if they see you go in. I am taking the bunker key with me. Three fuses were pulled from the generator: one in each lab, one here."},
"n_maint": {"title": "Technician Scrawl", "text": "Generator needs all three fuses. It is LOUD. Every time one goes in, the Watcher hears it. Do them in order and keep a locker near."},
"n_bun": {"title": "Vance - Last Entry", "text": "There was no audit. The night guard is the lure, and the guard before him, and before him. Subject 7 was Robert Hale, night shift, Halden Station. His badge is still on its chest. Whoever reads this, you were hired for the same shift."}
},
"endings": {
"ESCAPE": {"title": "ENDING: ESCAPE", "text": "The gate rolls open and the forest swallows the sound of the generator. You drive until dawn and do not stop. You will never know what was behind you."},
"TRUTH": {"title": "ENDING: THE TRUTH", "text": "You carry every page out of Halden Station. At sunrise the records reach the right people. The Watcher is found beside the gate, its badge in its hand. Robert Hale finally gets a name on a grave."},
"PURGE": {"title": "ENDING: PURGE", "text": "The purge sequence lights the facility from the inside. Through the gate you watch the Watcher stand perfectly still in the fire. It does not run. It was never meant to leave."}
}
}
