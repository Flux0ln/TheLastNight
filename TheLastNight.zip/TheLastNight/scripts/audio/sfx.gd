extends Node
## Autoload "Sfx": all audio is synthesized at runtime (no audio asset files, no licensing issues).
## Streams are built lazily and cached; one-shot playback uses small player pools.

const RATE := 16000

var _cache := {}
var _rng := RandomNumberGenerator.new()
var _pool2d: Array = []
var _pool3d: Array = []
var _i2 := 0
var _i3 := 0
var _wind: AudioStreamPlayer
var _hum: AudioStreamPlayer
var _drone: AudioStreamPlayer
var _danger: AudioStreamPlayer
var _heart: AudioStreamPlayer
var _alarm: AudioStreamPlayer
var _silence_t := 0.0
var ambience_on := false


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_rng.seed = 1337
	for i in 8:
		var p := AudioStreamPlayer.new()
		p.bus = "SFX"
		add_child(p)
		_pool2d.append(p)
		var q := AudioStreamPlayer3D.new()
		q.bus = "SFX"
		q.max_distance = 60.0
		add_child(q)
		_pool3d.append(q)


# ---------- synthesis helpers ----------
func _noise(n: int) -> PackedFloat32Array:
	var a := PackedFloat32Array()
	a.resize(n)
	for i in n:
		a[i] = _rng.randf_range(-1.0, 1.0)
	return a


func _lowpass(a: PackedFloat32Array, k: float) -> PackedFloat32Array:
	var y := 0.0
	for i in a.size():
		y += k * (a[i] - y)
		a[i] = y
	return a


func _norm(a: PackedFloat32Array, peak: float) -> PackedFloat32Array:
	var m := 0.0001
	for i in a.size():
		m = maxf(m, absf(a[i]))
	var g := peak / m
	for i in a.size():
		a[i] *= g
	return a


func _wav(a: PackedFloat32Array, loop: bool) -> AudioStreamWAV:
	var data := PackedByteArray()
	data.resize(a.size() * 2)
	for i in a.size():
		data.encode_s16(i * 2, int(clampf(a[i], -1.0, 1.0) * 32000.0))
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = RATE
	w.stereo = false
	w.data = data
	if loop:
		w.loop_mode = AudioStreamWAV.LOOP_FORWARD
		w.loop_begin = 0
		w.loop_end = a.size()
	return w


func _build(sname: String) -> AudioStreamWAV:
	var s := PackedFloat32Array()
	var loop := false
	var peak := 0.6
	match sname:
		"wind":
			var n := RATE * 3
			s = _lowpass(_noise(n), 0.04)
			for i in n:
				var t := float(i) / RATE
				s[i] *= 1.6 + sin(TAU * t / 3.0)
			loop = true
			peak = 0.5
		"hum":
			var n := RATE
			s.resize(n)
			for i in n:
				var t := float(i) / RATE
				s[i] = sin(TAU * 50.0 * t) * 0.5 + sin(TAU * 100.0 * t) * 0.3 + sin(TAU * 150.0 * t) * 0.15 + sin(TAU * 350.0 * t) * 0.05
			loop = true
			peak = 0.25
		"step_concrete", "step_metal", "step_grass":
			var n := int(RATE * 0.14)
			var k := 0.25
			var decay := 30.0
			if sname == "step_metal":
				k = 0.35
				decay = 25.0
			elif sname == "step_grass":
				k = 0.12
				decay = 20.0
			s = _lowpass(_noise(n), k)
			for i in n:
				var t := float(i) / RATE
				s[i] *= exp(-t * decay)
				if sname == "step_metal":
					s[i] += sin(TAU * 640.0 * t) * exp(-t * 40.0) * 0.15
			peak = 0.6 if sname != "step_grass" else 0.4
		"door":
			var n := int(RATE * 0.9)
			var nz := _lowpass(_noise(n), 0.08)
			s.resize(n)
			var ph := 0.0
			for i in n:
				var t := float(i) / RATE
				ph += TAU * (140.0 - 70.0 * t / 0.9) / RATE
				s[i] = (sin(ph) * 0.4 + nz[i] * 1.5) * minf(t * 20.0, 1.0) * exp(-t * 2.5)
			peak = 0.5
		"locked":
			var n := int(RATE * 0.25)
			var nz2 := _noise(n)
			s.resize(n)
			for i in n:
				var t := float(i) / RATE
				s[i] = sin(TAU * 80.0 * t) * exp(-t * 25.0) + nz2[i] * exp(-t * 60.0) * 0.4
		"pickup":
			var n := int(RATE * 0.25)
			s.resize(n)
			for i in n:
				var t := float(i) / RATE
				var f := 880.0 if t < 0.1 else 1320.0
				s[i] = sin(TAU * f * t) * exp(-t * 14.0)
			peak = 0.4
		"click":
			var n := int(RATE * 0.04)
			s = _noise(n)
			for i in n:
				s[i] *= exp(-float(i) / RATE * 90.0)
			peak = 0.4
		"clang":
			var n := int(RATE * 1.6)
			s.resize(n)
			for i in n:
				var t := float(i) / RATE
				s[i] = (sin(TAU * 420.0 * t) + sin(TAU * 933.0 * t) * 0.7 + sin(TAU * 1480.0 * t) * 0.5 + sin(TAU * 2210.0 * t) * 0.3) * exp(-t * 3.2)
			peak = 0.5
		"heartbeat":
			var n := RATE
			s.resize(n)
			for i in n:
				var t := float(i) / RATE
				var v := sin(TAU * 55.0 * t) * exp(-t * 18.0)
				if t >= 0.22:
					v += sin(TAU * 55.0 * (t - 0.22)) * exp(-(t - 0.22) * 18.0) * 0.8
				s[i] = v
			loop = true
			peak = 0.9
		"growl":
			var n := int(RATE * 1.4)
			var nz3 := _noise(n)
			s.resize(n)
			for i in n:
				var t := float(i) / RATE
				var saw := fposmod(t * 48.0, 1.0) * 2.0 - 1.0
				s[i] = (saw * 0.6 + nz3[i] * 0.4) * (0.6 + 0.4 * sin(TAU * 14.0 * t)) * sin(PI * t / 1.4)
			s = _lowpass(s, 0.15)
			peak = 0.9
		"breath":
			var n := RATE * 3
			s = _lowpass(_noise(n), 0.12)
			for i in n:
				var t := float(i) / RATE
				var e := sin(PI * fposmod(t, 1.5) / 1.5)
				s[i] *= e * e
			loop = true
			peak = 0.45
		"alarm":
			var n := RATE * 2
			s.resize(n)
			for i in n:
				var t := float(i) / RATE
				var f := 700.0 if int(t * 2.0) % 2 == 0 else 520.0
				s[i] = signf(sin(TAU * f * t)) * 0.25
			s = _lowpass(s, 0.4)
			loop = true
			peak = 0.4
		"stinger":
			var n := int(RATE * 1.2)
			var nz4 := _lowpass(_noise(n), 0.5)
			s.resize(n)
			for i in n:
				var t := float(i) / RATE
				s[i] = nz4[i] * exp(-t * 4.0) * 0.8 + sin(TAU * 70.0 * t) * exp(-t * 3.0) * 0.6 + sin(TAU * 1500.0 * t) * exp(-t * 8.0) * 0.2
			peak = 0.85
		"hurt":
			var n := int(RATE * 0.35)
			var nz5 := _lowpass(_noise(n), 0.2)
			s.resize(n)
			for i in n:
				var t := float(i) / RATE
				s[i] = nz5[i] * exp(-t * 10.0) + sin(TAU * 100.0 * t) * exp(-t * 12.0) * 0.5
			peak = 0.8
		"drone":
			var n := RATE * 4
			s.resize(n)
			for i in n:
				var t := float(i) / RATE
				s[i] = sin(TAU * 55.0 * t) * 0.5 + sin(TAU * 55.25 * t) * 0.5 + sin(TAU * 82.5 * t) * 0.25 + sin(TAU * 110.0 * t) * 0.15 * (0.5 + 0.5 * sin(TAU * 0.25 * t))
			loop = true
			peak = 0.5
		"danger":
			var n := RATE * 2
			s.resize(n)
			for i in n:
				var t := float(i) / RATE
				var env := pow(maxf(0.0, sin(TAU * 2.0 * t)), 2.0)
				s[i] = ((fposmod(t * 110.0, 1.0) * 2.0 - 1.0) * 0.5 + sin(TAU * 220.0 * t) * 0.2) * env
			s = _lowpass(s, 0.15)
			loop = true
			peak = 0.6
		_:
			s.resize(10)
	return _wav(_norm(s, peak), loop)


func get_stream(sname: String) -> AudioStreamWAV:
	if not _cache.has(sname):
		_cache[sname] = _build(sname)
	return _cache[sname]


# ---------- playback ----------
func play(sname: String, db := 0.0, pitch := 1.0) -> void:
	var p: AudioStreamPlayer = _pool2d[_i2]
	_i2 = (_i2 + 1) % _pool2d.size()
	p.stream = get_stream(sname)
	p.volume_db = db
	p.pitch_scale = pitch
	p.play()


func play_at(sname: String, pos: Vector3, db := 0.0, unit := 8.0, pitch := 1.0) -> void:
	var p: AudioStreamPlayer3D = _pool3d[_i3]
	_i3 = (_i3 + 1) % _pool3d.size()
	p.stream = get_stream(sname)
	p.global_position = pos
	p.volume_db = db
	p.unit_size = unit
	p.pitch_scale = pitch
	p.play()


func _loop(sname: String, bus: String, db: float) -> AudioStreamPlayer:
	var p := AudioStreamPlayer.new()
	p.stream = get_stream(sname)
	p.bus = bus
	p.volume_db = db
	add_child(p)
	p.play()
	return p


func start_menu_music() -> void:
	stop_ambience()
	_drone = _loop("drone", "Music", -8.0)


func start_ambience() -> void:
	stop_ambience()
	ambience_on = true
	_wind = _loop("wind", "SFX", -14.0)
	_hum = _loop("hum", "SFX", -28.0)
	_drone = _loop("drone", "Music", -12.0)
	_danger = _loop("danger", "Music", -80.0)
	_heart = _loop("heartbeat", "SFX", -80.0)


func stop_ambience() -> void:
	ambience_on = false
	for p in [_wind, _hum, _drone, _danger, _heart, _alarm]:
		if p != null and is_instance_valid(p):
			p.queue_free()
	_wind = null
	_hum = null
	_drone = null
	_danger = null
	_heart = null
	_alarm = null


func set_danger(v: float) -> void:
	if _danger == null:
		return
	_danger.volume_db = linear_to_db(maxf(v * v * 0.8, 0.0001))
	_heart.volume_db = linear_to_db(maxf(v * 0.9, 0.0001)) if v > 0.25 else -80.0
	_heart.pitch_scale = 0.9 + v * 0.5
	if _drone != null:
		_drone.volume_db = lerpf(-12.0, -22.0, v)


func silence(secs: float) -> void:
	_silence_t = secs


func start_alarm(secs: float) -> void:
	if _alarm != null and is_instance_valid(_alarm):
		_alarm.queue_free()
	_alarm = _loop("alarm", "SFX", -10.0)
	var tw := create_tween()
	tw.tween_interval(secs)
	tw.tween_callback(func():
		if _alarm != null and is_instance_valid(_alarm):
			_alarm.queue_free()
			_alarm = null)


func _process(delta: float) -> void:
	if _wind == null:
		return
	if _silence_t > 0.0:
		_silence_t -= delta
		_wind.volume_db = lerpf(_wind.volume_db, -60.0, 4.0 * delta)
		_hum.volume_db = lerpf(_hum.volume_db, -60.0, 4.0 * delta)
	else:
		_wind.volume_db = lerpf(_wind.volume_db, -14.0, 1.5 * delta)
		_hum.volume_db = lerpf(_hum.volume_db, -28.0, 1.5 * delta)
