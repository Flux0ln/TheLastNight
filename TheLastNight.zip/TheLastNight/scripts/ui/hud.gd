extends CanvasLayer
## HUD, pause menu, notes, death/ending screens, touch controls.

signal restart_requested
signal menu_requested

const UITheme = preload("res://scripts/ui/ui_theme.gd")
const SettingsPanel = preload("res://scripts/ui/settings_panel.gd")
const TouchControls = preload("res://scripts/ui/touch_controls.gd")

var touch
var root: Control
var layer: Control
var health_bar: ProgressBar
var stamina_bar: ProgressBar
var battery_bar: ProgressBar
var inv_label: Label
var objective_label: Label
var prompt_label: Label
var msg_label: Label
var vignette: TextureRect
var flash_rect: ColorRect
var hide_top: ColorRect
var hide_bottom: ColorRect
var pause_overlay: Control
var settings_overlay: Control
var note_overlay: Control
var note_title: Label
var note_body: Label
var death_overlay: Control
var end_overlay: Control
var end_title: Label
var end_body: Label
var _msg_t := 0.0
var _blocking := false


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	layer = Control.new()
	root = layer
	root.theme = UITheme.make()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(root)
	_build_vignette()
	_build_hud()
	touch = TouchControls.new()
	touch.visible = bool(Game.settings["touch"])
	root.add_child(touch)
	_build_fx()
	pause_overlay = _build_pause()
	settings_overlay = _build_settings()
	note_overlay = _build_note()
	death_overlay = _build_death()
	end_overlay = _build_end()


func _safe_margins() -> Vector4:
	var m := Vector4(16, 12, 16, 12)
	if OS.has_feature("mobile"):
		var safe := DisplayServer.get_display_safe_area()
		var scr := DisplayServer.screen_get_size()
		var win := get_viewport().get_visible_rect().size
		if scr.x > 0 and scr.y > 0:
			var sx := win.x / float(scr.x)
			var sy := win.y / float(scr.y)
			m.x += float(safe.position.x) * sx
			m.y += float(safe.position.y) * sy
			m.z += float(scr.x - safe.end.x) * sx
			m.w += float(scr.y - safe.end.y) * sy
	return m


func _build_vignette() -> void:
	var g := Gradient.new()
	g.offsets = PackedFloat32Array([0.45, 1.0])
	g.colors = PackedColorArray([Color(0, 0, 0, 0), Color(0.45, 0.0, 0.0, 0.95)])
	var gt := GradientTexture2D.new()
	gt.gradient = g
	gt.fill = GradientTexture2D.FILL_RADIAL
	gt.fill_from = Vector2(0.5, 0.5)
	gt.fill_to = Vector2(1.0, 0.5)
	gt.width = 128
	gt.height = 128
	vignette = TextureRect.new()
	vignette.texture = gt
	vignette.set_anchors_preset(Control.PRESET_FULL_RECT)
	vignette.stretch_mode = TextureRect.STRETCH_SCALE
	vignette.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	vignette.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vignette.modulate.a = 0.0
	root.add_child(vignette)


func _build_hud() -> void:
	var m := _safe_margins()
	var mc := MarginContainer.new()
	mc.set_anchors_preset(Control.PRESET_FULL_RECT)
	mc.mouse_filter = Control.MOUSE_FILTER_IGNORE
	mc.add_theme_constant_override("margin_left", int(m.x))
	mc.add_theme_constant_override("margin_top", int(m.y))
	mc.add_theme_constant_override("margin_right", int(m.z))
	mc.add_theme_constant_override("margin_bottom", int(m.w))
	root.add_child(mc)
	var holder := Control.new()
	holder.mouse_filter = Control.MOUSE_FILTER_IGNORE
	mc.add_child(holder)

	objective_label = Label.new()
	objective_label.custom_minimum_size = Vector2(520, 0)
	objective_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	objective_label.add_theme_font_size_override("font_size", 20)
	objective_label.add_theme_color_override("font_color", Color(0.85, 0.8, 0.7))
	holder.add_child(objective_label)

	var stats := VBoxContainer.new()
	stats.mouse_filter = Control.MOUSE_FILTER_IGNORE
	holder.add_child(stats)
	stats.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT, Control.PRESET_MODE_MINSIZE, 0)
	stats.grow_horizontal = Control.GROW_DIRECTION_BEGIN
	health_bar = UITheme.bar(Color(0.75, 0.1, 0.1))
	stamina_bar = UITheme.bar(Color(0.8, 0.8, 0.85))
	battery_bar = UITheme.bar(Color(0.95, 0.8, 0.2))
	stats.add_child(health_bar)
	stats.add_child(stamina_bar)
	stats.add_child(battery_bar)
	inv_label = Label.new()
	inv_label.add_theme_font_size_override("font_size", 18)
	inv_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	stats.add_child(inv_label)

	var dot := ColorRect.new()
	dot.color = Color(1, 1, 1, 0.6)
	dot.custom_minimum_size = Vector2(4, 4)
	dot.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(dot)
	dot.set_anchors_and_offsets_preset(Control.PRESET_CENTER, Control.PRESET_MODE_MINSIZE, 0)

	prompt_label = Label.new()
	prompt_label.add_theme_font_size_override("font_size", 26)
	prompt_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	root.add_child(prompt_label)
	prompt_label.set_anchors_and_offsets_preset(Control.PRESET_CENTER, Control.PRESET_MODE_MINSIZE, 0)
	prompt_label.position.y += 70
	prompt_label.grow_horizontal = Control.GROW_DIRECTION_BOTH

	msg_label = Label.new()
	msg_label.add_theme_font_size_override("font_size", 24)
	msg_label.add_theme_color_override("font_color", Color(0.95, 0.85, 0.6))
	msg_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	msg_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	msg_label.custom_minimum_size = Vector2(700, 0)
	root.add_child(msg_label)
	msg_label.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP, Control.PRESET_MODE_MINSIZE, 0)
	msg_label.position.y += 70
	msg_label.grow_horizontal = Control.GROW_DIRECTION_BOTH

	var pb := Button.new()
	pb.text = "II"
	pb.custom_minimum_size = Vector2(64, 48)
	pb.pressed.connect(func(): set_paused(true))
	root.add_child(pb)
	pb.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP, Control.PRESET_MODE_MINSIZE, 8)
	pb.grow_horizontal = Control.GROW_DIRECTION_BOTH


func _build_fx() -> void:
	flash_rect = ColorRect.new()
	flash_rect.color = Color(0.8, 0, 0, 0)
	flash_rect.set_anchors_preset(Control.PRESET_FULL_RECT)
	flash_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(flash_rect)
	hide_top = ColorRect.new()
	hide_top.color = Color.BLACK
	hide_top.anchor_right = 1.0
	hide_top.anchor_bottom = 0.4
	hide_top.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hide_top.visible = false
	root.add_child(hide_top)
	hide_bottom = ColorRect.new()
	hide_bottom.color = Color.BLACK
	hide_bottom.anchor_right = 1.0
	hide_bottom.anchor_top = 0.6
	hide_bottom.anchor_bottom = 1.0
	hide_bottom.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hide_bottom.visible = false
	root.add_child(hide_bottom)


func _make_overlay(dim := 0.75) -> Array:
	var ov := Control.new()
	ov.set_anchors_preset(Control.PRESET_FULL_RECT)
	ov.visible = false
	root.add_child(ov)
	var bg := ColorRect.new()
	bg.color = Color(0, 0, 0, dim)
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	ov.add_child(bg)
	var cc := CenterContainer.new()
	cc.set_anchors_preset(Control.PRESET_FULL_RECT)
	ov.add_child(cc)
	var pc := PanelContainer.new()
	cc.add_child(pc)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 12)
	vb.custom_minimum_size = Vector2(520, 0)
	pc.add_child(vb)
	return [ov, vb]


func _btn(parent: Control, text: String, cb: Callable) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(0, 56)
	b.pressed.connect(cb)
	parent.add_child(b)
	return b


func _title(parent: Control, text: String) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", 34)
	l.add_theme_color_override("font_color", Color(0.8, 0.1, 0.1))
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	parent.add_child(l)
	return l


func _build_pause() -> Control:
	var a := _make_overlay()
	var vb: VBoxContainer = a[1]
	_title(vb, "PAUSED")
	_btn(vb, "Resume", func(): set_paused(false))
	_btn(vb, "Settings", func():
		pause_overlay.visible = false
		settings_overlay.visible = true)
	_btn(vb, "Restart Checkpoint", func(): restart_requested.emit())
	_btn(vb, "Main Menu", func(): menu_requested.emit())
	return a[0]


func _build_settings() -> Control:
	var ov := Control.new()
	ov.set_anchors_preset(Control.PRESET_FULL_RECT)
	ov.visible = false
	root.add_child(ov)
	var bg := ColorRect.new()
	bg.color = Color(0, 0, 0, 0.85)
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	ov.add_child(bg)
	var cc := CenterContainer.new()
	cc.set_anchors_preset(Control.PRESET_FULL_RECT)
	ov.add_child(cc)
	var sp := SettingsPanel.new()
	sp.closed.connect(func():
		settings_overlay.visible = false
		pause_overlay.visible = true)
	sp.changed.connect(func(): touch.visible = bool(Game.settings["touch"]); touch._layout())
	cc.add_child(sp)
	return ov


func _build_note() -> Control:
	var a := _make_overlay(0.8)
	var vb: VBoxContainer = a[1]
	vb.custom_minimum_size = Vector2(680, 0)
	note_title = _title(vb, "NOTE")
	note_body = Label.new()
	note_body.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	note_body.custom_minimum_size = Vector2(660, 0)
	note_body.add_theme_font_size_override("font_size", 22)
	vb.add_child(note_body)
	_btn(vb, "Close", func(): hide_note())
	return a[0]


func _build_death() -> Control:
	var a := _make_overlay(0.88)
	var vb: VBoxContainer = a[1]
	_title(vb, "YOU DIED")
	_btn(vb, "Restart Checkpoint", func(): restart_requested.emit())
	_btn(vb, "Main Menu", func(): menu_requested.emit())
	return a[0]


func _build_end() -> Control:
	var a := _make_overlay(0.92)
	var vb: VBoxContainer = a[1]
	vb.custom_minimum_size = Vector2(680, 0)
	end_title = _title(vb, "THE END")
	end_body = Label.new()
	end_body.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	end_body.custom_minimum_size = Vector2(660, 0)
	vb.add_child(end_body)
	_btn(vb, "Main Menu", func(): menu_requested.emit())
	return a[0]


# ---------- public API ----------
func set_stats(health: float, stamina: float, battery: float, inv: String) -> void:
	health_bar.value = health
	stamina_bar.value = stamina
	battery_bar.value = battery
	inv_label.text = inv


func set_objective(t: String) -> void:
	objective_label.text = "> " + t


func set_prompt(t: String) -> void:
	prompt_label.text = t


func message(t: String, secs := 3.0) -> void:
	msg_label.text = t
	_msg_t = secs


func set_danger(v: float) -> void:
	vignette.modulate.a = clampf(v * 0.9, 0.0, 0.85)


func set_hidden(v: bool) -> void:
	hide_top.visible = v
	hide_bottom.visible = v


func flash(c: Color) -> void:
	flash_rect.color = c
	var tw := create_tween()
	tw.tween_property(flash_rect, "color:a", 0.0, 0.5)


func show_note(title: String, text: String) -> void:
	note_title.text = title
	note_body.text = text
	note_overlay.visible = true
	_set_blocking(true)


func hide_note() -> void:
	note_overlay.visible = false
	_set_blocking(false)


func show_death() -> void:
	death_overlay.visible = true
	_set_blocking(true, false)


func show_ending(title: String, text: String) -> void:
	end_title.text = title
	end_body.text = text
	end_overlay.visible = true
	_set_blocking(true, false)


func set_paused(p: bool) -> void:
	if _blocking and p:
		return
	pause_overlay.visible = p
	settings_overlay.visible = false
	get_tree().paused = p
	_apply_mouse(p)


func _set_blocking(v: bool, pause_tree := true) -> void:
	_blocking = v
	if pause_tree:
		get_tree().paused = v
	_apply_mouse(v)


func _apply_mouse(show_cursor: bool) -> void:
	if show_cursor or bool(Game.settings["touch"]):
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	else:
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("pause") and not _blocking:
		set_paused(not pause_overlay.visible and not settings_overlay.visible)
	elif event.is_action_pressed("pause") and note_overlay.visible:
		hide_note()


func _process(delta: float) -> void:
	if _msg_t > 0.0:
		_msg_t -= delta
		if _msg_t <= 0.0:
			msg_label.text = ""
