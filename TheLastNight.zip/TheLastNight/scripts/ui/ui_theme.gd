extends RefCounted
## Builds the dark horror UI theme in code (no external theme/font assets).

static func _box(bg: Color, border: Color, bw := 2) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = bg
	sb.border_color = border
	sb.set_border_width_all(bw)
	sb.set_content_margin_all(14)
	return sb


static func make() -> Theme:
	var t := Theme.new()
	t.default_font_size = 24
	var panel := _box(Color(0.04, 0.04, 0.05, 0.95), Color(0.55, 0.05, 0.05))
	panel.set_content_margin_all(22)
	t.set_stylebox("panel", "PanelContainer", panel)
	t.set_stylebox("normal", "Button", _box(Color(0.09, 0.09, 0.11), Color(0.25, 0.25, 0.28), 1))
	t.set_stylebox("hover", "Button", _box(Color(0.25, 0.04, 0.04), Color(0.7, 0.1, 0.1)))
	t.set_stylebox("pressed", "Button", _box(Color(0.5, 0.05, 0.05), Color(0.9, 0.15, 0.15)))
	t.set_stylebox("disabled", "Button", _box(Color(0.06, 0.06, 0.07), Color(0.15, 0.15, 0.17), 1))
	t.set_stylebox("focus", "Button", StyleBoxEmpty.new())
	t.set_color("font_color", "Button", Color(0.9, 0.9, 0.92))
	t.set_color("font_disabled_color", "Button", Color(0.4, 0.4, 0.42))
	t.set_color("font_color", "Label", Color(0.88, 0.88, 0.9))
	t.set_color("font_color", "CheckButton", Color(0.88, 0.88, 0.9))
	t.set_color("font_color", "OptionButton", Color(0.9, 0.9, 0.92))
	t.set_stylebox("normal", "OptionButton", _box(Color(0.09, 0.09, 0.11), Color(0.25, 0.25, 0.28), 1))
	t.set_stylebox("hover", "OptionButton", _box(Color(0.25, 0.04, 0.04), Color(0.7, 0.1, 0.1)))
	t.set_stylebox("pressed", "OptionButton", _box(Color(0.5, 0.05, 0.05), Color(0.9, 0.15, 0.15)))
	return t


static func bar(color: Color) -> ProgressBar:
	var b := ProgressBar.new()
	b.show_percentage = false
	b.custom_minimum_size = Vector2(230, 14)
	b.max_value = 100.0
	var fill := StyleBoxFlat.new()
	fill.bg_color = color
	var bg := StyleBoxFlat.new()
	bg.bg_color = Color(0, 0, 0, 0.55)
	b.add_theme_stylebox_override("fill", fill)
	b.add_theme_stylebox_override("background", bg)
	return b
