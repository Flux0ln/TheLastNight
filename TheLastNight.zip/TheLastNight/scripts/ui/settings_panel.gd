extends PanelContainer
## Shared settings panel (main menu + pause menu).

signal closed
signal changed


func _ready() -> void:
	custom_minimum_size = Vector2(660, 0)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 10)
	add_child(vb)
	var title := Label.new()
	title.text = "SETTINGS"
	title.add_theme_color_override("font_color", Color(0.8, 0.1, 0.1))
	vb.add_child(title)
	_slider(vb, "Master volume", "master", 0.0, 1.0)
	_slider(vb, "Music volume", "music", 0.0, 1.0)
	_slider(vb, "Effects volume", "sfx", 0.0, 1.0)
	_slider(vb, "Look sensitivity", "sens", 0.3, 3.0)
	var qrow := HBoxContainer.new()
	var ql := Label.new()
	ql.text = "Graphics quality"
	ql.custom_minimum_size = Vector2(260, 0)
	qrow.add_child(ql)
	var opt := OptionButton.new()
	opt.add_item("Low")
	opt.add_item("Medium")
	opt.add_item("High")
	opt.select(int(Game.settings["quality"]))
	opt.item_selected.connect(func(i: int):
		Game.settings["quality"] = i
		Game.apply_quality(get_viewport())
		changed.emit())
	opt.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	qrow.add_child(opt)
	vb.add_child(qrow)
	var chk := CheckButton.new()
	chk.text = "Touch controls"
	chk.button_pressed = bool(Game.settings["touch"])
	chk.toggled.connect(func(v: bool):
		Game.settings["touch"] = v
		changed.emit())
	vb.add_child(chk)
	_slider(vb, "Touch button size", "touch_scale", 0.7, 1.5)
	var back := Button.new()
	back.text = "Back"
	back.pressed.connect(func():
		Game.save_settings()
		closed.emit())
	vb.add_child(back)


func _slider(parent: Control, label: String, key: String, lo: float, hi: float) -> void:
	var row := HBoxContainer.new()
	var l := Label.new()
	l.text = label
	l.custom_minimum_size = Vector2(260, 0)
	row.add_child(l)
	var s := HSlider.new()
	s.min_value = lo
	s.max_value = hi
	s.step = 0.05
	s.value = float(Game.settings[key])
	s.custom_minimum_size = Vector2(300, 32)
	s.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	s.value_changed.connect(func(v: float):
		Game.settings[key] = v
		Game.apply_audio()
		changed.emit())
	row.add_child(s)
	parent.add_child(row)
