extends Control
## On-screen controls: floating joystick (left), look area (right), action buttons.

signal interact_pressed
signal flashlight_pressed
signal reload_pressed

var move_vec := Vector2.ZERO
var run_held := false
var crouch_on := false
var _look := Vector2.ZERO
var _joy_id := -1
var _look_id := -1
var _joy_center := Vector2.ZERO
var _btn_touch := {}
var _buttons := {}


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_preset(Control.PRESET_FULL_RECT)
	resized.connect(_layout)
	_layout()


func _layout() -> void:
	var w := size.x
	var h := size.y
	var sc := float(Game.settings["touch_scale"])
	_buttons = {
		"interact": {"c": Vector2(w - 120, h - 150), "r": 62.0 * sc, "t": "USE"},
		"run": {"c": Vector2(w - 260, h - 105), "r": 48.0 * sc, "t": "RUN"},
		"crouch": {"c": Vector2(w - 120, h - 290), "r": 44.0 * sc, "t": "DUCK"},
		"flash": {"c": Vector2(w - 260, h - 235), "r": 42.0 * sc, "t": "LIGHT"},
		"reload": {"c": Vector2(w - 380, h - 95), "r": 38.0 * sc, "t": "BATT"},
	}
	queue_redraw()


func consume_look() -> Vector2:
	var v := _look
	_look = Vector2.ZERO
	return v


func _hit_button(pos: Vector2) -> String:
	for n in _buttons:
		var b: Dictionary = _buttons[n]
		if pos.distance_to(b["c"]) <= float(b["r"]) * 1.15:
			return n
	return ""


func _input(event: InputEvent) -> void:
	if not visible:
		return
	if event is InputEventScreenTouch:
		if event.pressed:
			_press(event.index, event.position)
		else:
			_release(event.index)
	elif event is InputEventScreenDrag:
		_drag(event.index, event.position, event.relative)


func _press(idx: int, pos: Vector2) -> void:
	var btn := _hit_button(pos)
	if btn != "":
		_btn_touch[idx] = btn
		match btn:
			"interact": interact_pressed.emit()
			"flash": flashlight_pressed.emit()
			"reload": reload_pressed.emit()
			"run": run_held = true
			"crouch": crouch_on = not crouch_on
		queue_redraw()
		return
	if pos.x < size.x * 0.4 and pos.y > size.y * 0.25 and _joy_id == -1:
		_joy_id = idx
		_joy_center = pos
		move_vec = Vector2.ZERO
	elif _look_id == -1:
		_look_id = idx
	queue_redraw()


func _release(idx: int) -> void:
	if _btn_touch.has(idx):
		if _btn_touch[idx] == "run":
			run_held = false
		_btn_touch.erase(idx)
	if idx == _joy_id:
		_joy_id = -1
		move_vec = Vector2.ZERO
	if idx == _look_id:
		_look_id = -1
	queue_redraw()


func _drag(idx: int, pos: Vector2, rel: Vector2) -> void:
	if idx == _joy_id:
		var r := 90.0 * float(Game.settings["touch_scale"])
		move_vec = ((pos - _joy_center) / r).limit_length(1.0)
		queue_redraw()
	elif idx == _look_id:
		_look += rel


func _draw() -> void:
	var sc := float(Game.settings["touch_scale"])
	var font := ThemeDB.fallback_font
	if _joy_id != -1:
		draw_circle(_joy_center, 90.0 * sc, Color(1, 1, 1, 0.07))
		draw_arc(_joy_center, 90.0 * sc, 0.0, TAU, 32, Color(1, 1, 1, 0.3), 2.0)
		draw_circle(_joy_center + move_vec * 90.0 * sc, 36.0 * sc, Color(0.8, 0.1, 0.1, 0.5))
	else:
		draw_arc(Vector2(150, size.y - 170), 70.0 * sc, 0.0, TAU, 32, Color(1, 1, 1, 0.12), 2.0)
	for n in _buttons:
		var b: Dictionary = _buttons[n]
		var pressed := _btn_touch.values().has(n) or (n == "crouch" and crouch_on)
		var c: Vector2 = b["c"]
		var r: float = b["r"]
		draw_circle(c, r, Color(0.7, 0.05, 0.05, 0.45) if pressed else Color(1, 1, 1, 0.1))
		draw_arc(c, r, 0.0, TAU, 28, Color(1, 1, 1, 0.35), 2.0)
		draw_string(font, c + Vector2(-r, 7), b["t"], HORIZONTAL_ALIGNMENT_CENTER, r * 2.0, 20, Color(1, 1, 1, 0.85))
