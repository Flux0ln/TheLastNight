extends StaticBody3D
## Sliding door. Closed doors block the player and sight; the Watcher opens doors itself.

var id := ""
var lock := ""
var needs_power := false
var is_open := false
var level = null
var shape: CollisionShape3D
var closed_y := 0.0
var open_y := 0.0
var _tween: Tween


func setup(p_id: String, p_lock: String, p_power: bool, size: Vector3, mat: Material, wall_h: float) -> void:
	id = p_id
	lock = p_lock
	needs_power = p_power
	collision_layer = 8
	collision_mask = 0
	add_to_group("doors")
	shape = CollisionShape3D.new()
	var sh := BoxShape3D.new()
	sh.size = size
	shape.shape = sh
	add_child(shape)
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.material_override = mat
	add_child(mi)
	closed_y = wall_h * 0.5
	open_y = wall_h * 1.5 - 0.1
	position.y = closed_y


func set_open(value: bool, by_monster := false) -> void:
	if value == is_open:
		return
	is_open = value
	shape.set_deferred("disabled", value)
	if _tween != null and _tween.is_valid():
		_tween.kill()
	_tween = create_tween()
	_tween.tween_property(self, "position:y", open_y if value else closed_y, 0.6)
	Sfx.play_at("door", global_position, 0.0, 10.0)
	Game.make_noise(global_position, 6.0 if by_monster else 10.0)


func prompt(_player) -> String:
	return level.prompt_for_door(self)


func interact(player) -> void:
	level.handle_door(self, player)
