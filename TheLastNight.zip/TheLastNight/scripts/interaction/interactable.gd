extends StaticBody3D
## Generic interactable (pickups, lockers, generator, terminal). Logic lives in level.gd.

var kind := ""
var id := ""
var data := {}
var level = null
var face := Vector3(0, 0, 1)


func add_box_shape(size: Vector3, offset := Vector3.ZERO) -> void:
	var cs := CollisionShape3D.new()
	var sh := BoxShape3D.new()
	sh.size = size
	cs.shape = sh
	cs.position = offset
	add_child(cs)


func prompt(_player) -> String:
	return level.prompt_for(self)


func interact(player) -> void:
	level.handle_interact(self, player)
