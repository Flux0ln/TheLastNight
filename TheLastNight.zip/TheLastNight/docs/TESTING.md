# Testing status

| Check | Status |
|---|---|
| Layout data parses; items/doors on valid cells; rooms sealed; key/fuse/power chain solvable; exit reachable | **Passed** (`python3 tests/validate_layout.py`) |
| Project opens in Godot without errors | **Not tested** |
| GDScript parse errors / invalid node paths | **Not tested** (no Godot binary available) |
| Movement, crouch, sprint, flashlight, batteries | Not tested |
| Watcher patrol / hearing / chase / search / stuck recovery | Not tested (`tests/smoke_test.gd` written, never run) |
| Doors, keys, fuses, generator, endings | Not tested in-engine (logic chain verified statically only) |
| Save / load / restart checkpoint | Not tested |
| Touch controls on a real Android device | Not tested |
| Android export | Not tested |
| Performance (30 FPS low-end target) | Not measured |

## How to test
1. `python3 tests/validate_layout.py`
2. Open in Godot 4.3, fix any reported parse errors (check the Output / Debugger panels).
3. Headless smoke test: `godot --headless --path . -s tests/smoke_test.gd`
4. Manual pass: collect all fuses, power on, take exit card, reach the north gate. Try hiding with and without being seen; die and use Restart Checkpoint; Continue from the menu.
5. Android: export a debug APK, check joystick/look/buttons, safe-area margins, and FPS on Low preset.
