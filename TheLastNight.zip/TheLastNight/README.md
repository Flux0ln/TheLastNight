# THE LAST NIGHT

First-person low-poly survival horror for **Godot 4.3+ (GDScript, Mobile renderer)**. Primary target: Android. Windows/Linux/macOS desktop works with keyboard + mouse.

You are the night guard at Halden Research Station. Power is failing, the doors are locked, and something called **the Watcher** listens for you in the dark.

> **Status: first complete draft, NOT yet opened in Godot.** No Godot binary was available where this was written, so nothing here has been run. Expect a few parse errors / invalid-path fixes on first open (see `docs/TESTING.md`). Everything marked "implemented" below means the code exists, not that it has been play-tested.

## Features (implemented in code)
- First-person walk / run (stamina) / crouch, head bob, mouse look, touch joystick + look area + buttons
- Flashlight with draining battery, spare batteries (`R` / BATT), flicker when low
- Interaction ray: pickups, notes (8), keys (3), fuses (3), doors (open/close/locked), generator, terminal
- Lockers for hiding (not safe if the Watcher saw you enter), two safe rooms (office, bunker) with slow healing and noise immunity
- The Watcher: patrol / investigate / search / chase / attack, sight cone + line-of-sight raycast, hearing (footsteps, sprint, doors, pickups, generator), last-known-position search, difficulty ramps with fuses and power, stuck recovery (nudge, then teleport), opens doors itself, runtime-baked `NavigationRegion3D`
- Three scripted first-sight encounters, random minor events, flickering lights, red emergency lighting -> white after power-on
- Checkpoints (safe rooms, fuse insertions, power-on), Continue / restart checkpoint, JSON save in `user://`
- Three endings: **ESCAPE**, **TRUTH** (all 8 notes), **PURGE** (arm the terminal)
- All audio synthesized at runtime (wind, hum, steps per surface, heartbeat, growl, breathing, alarm, adaptive music)
- Settings: master/music/effects volume, sensitivity, graphics Low/Medium/High (render scale, MSAA, flashlight shadows), touch size, safe-area margins
- Everything built procedurally from `scripts/managers/layout.gd`; no external assets

## Run
1. Install Godot **4.3** (standard build, not .NET).
2. Open `project.godot`, let it import, press **F5**.

## Controls
| Action | Keyboard | Touch |
|---|---|---|
| Move | WASD / arrows | left joystick (floating) |
| Look | mouse | drag right side |
| Run (hold) | Shift | RUN |
| Crouch | hold C / Ctrl | DUCK (toggle) |
| Interact | E | USE |
| Flashlight | F | LIGHT |
| Replace battery | R | BATT |
| Pause | Esc | II button |

## Goal
Find 3 fuses (lab W, lab E, security room) -> install at the generator (north hall) -> power returns and the Watcher hunts you -> grab the exit card (bunker) -> run to the north gate. Keys: office -> security key; security -> bunker key; bunker -> exit card.

## Android export
1. Install Android SDK + JDK 17, set paths in Godot: Editor Settings -> Export -> Android.
2. Project -> Install Android Build Template.
3. Project -> Export -> Add **Android**. Use the Mobile renderer, landscape orientation (already set), enable ARM64, create/choose a keystore (debug keystore is fine for testing).
4. Export APK/AAB. `export_presets.cfg` is gitignored on purpose (it holds keystore paths).

## Project structure
```
project.godot  icon.svg  README.md  LICENSE
scenes/menus/main_menu.tscn   scenes/levels/game.tscn   (thin; everything else is built in code)
scripts/managers/  game.gd (autoload) level.gd layout.gd main_menu.gd
scripts/player/player.gd      scripts/ai/watcher.gd
scripts/interaction/  interactable.gd door.gd
scripts/audio/sfx.gd (autoload, procedural audio)
scripts/ui/  hud.gd touch_controls.gd settings_panel.gd ui_theme.gd
tests/  validate_layout.py (runs anywhere)  smoke_test.gd (needs Godot)
docs/TESTING.md   assets/ (empty placeholders)
```

## Asset licensing
No third-party assets. Models are primitives, audio is generated in code, UI uses the default Godot font. Code is MIT (see `LICENSE`).

## Known limitations / not done
- **Never run in Godot yet** (see status above). Android build, touch controls, navmesh baking and performance are all untested.
- Map is one floor; the "underground bunker" is a single sealed corridor (the optional secret room) rather than a separate level.
- Monster uses a box-built model with simple procedural animation, no skeletal rig.
- Doors are not on the navmesh; the Watcher ignores locked doors (it opens them itself).
- Mobile renderer caps lights per mesh, so long wall runs may ignore some room lights.
- Surface sounds: concrete / metal / grass only. No object dropping/throwing mechanic. No inventory screen (counts shown in the HUD).
- Save stores checkpoint state only (not a mid-chase snapshot).
